/**
 * Doge Clicker Game - Complete Source Code
 *
 * This file contains the entire source code for the Doge Clicker game.
 * Created by: ATCM Gaming
 * Date: May 12, 2025
 *
 * This file includes:
 * - App and main rendering components
 * - Game context and state management
 * - Game logic and utilities
 * - UI components including ASCII Doge, Controls, LongDoge, etc.
 * - Shop, Achievements, and Save/Load functionality
 * - Backend routes and storage logic
 * - Database schema
 * - Utility hooks and functions
 *
 * © 2025 ATCM Gaming. All rights reserved.
 */

import { useState, useEffect } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Switch, Route } from "wouter";
import { GameProvider } from "./lib/GameContext";
import Home from "@/pages/Home";
import NotFound from "@/pages/not-found";
import logoImage from "./assets/atcm-logo.webp";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [showLogoOnly, setShowLogoOnly] = useState(true);

  // First show logo for 3 seconds, then loading screen for 2 seconds
  useEffect(() => {
    // After 3 seconds, switch from logo to loading bar
    const logoTimer = setTimeout(() => {
      setShowLogoOnly(false);
    }, 3000);

    // After total 5 seconds, finish loading
    const loadingTimer = setTimeout(() => {
      setIsLoading(false);
    }, 5000);

    return () => {
      clearTimeout(logoTimer);
      clearTimeout(loadingTimer);
    };
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <GameProvider>
          <Toaster />
          {isLoading ? (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#F0E8DC] dark:bg-[#E3DDD1]">
              {showLogoOnly ? (
                <div className="flex flex-col items-center justify-center h-screen w-screen">
                  <img
                    src={logoImage}
                    alt="ATCM Gaming Logo"
                    className="max-h-screen max-w-screen-md w-auto h-auto"
                  />
                </div>
              ) : (
                <div className="text-center">
                  <h2
                    className="text-2xl font-bold mb-4 text-[#5D534A]"
                    style={{
                      fontFamily:
                        "'Comic Sans MS', 'Comic Neue', 'Chalkboard SE', sans-serif",
                    }}
                  >
                    Loading Doge Clicker...
                  </h2>
                  <div className="w-64 h-2 bg-[#DDD6CA] rounded-full overflow-hidden">
                    <div className="h-full bg-[#A69D8D] animate-loading"></div>
                  </div>
                  <p className="mt-4 text-sm text-[#8A7E6B]">
                    wow such loading, very wait
                  </p>
                </div>
              )}
            </div>
          ) : (
            <Router />
          )}
        </GameProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
import { useRef, useCallback, useState } from "react";
import { Helmet } from "react-helmet";
import Controls from "@/components/Controls";
import AsciiDoge from "@/components/AsciiDoge";
import { personalityTraits } from "@/lib/dogePersonality";
import UpgradeShop from "@/components/UpgradeShop";
import Achievements from "@/components/Achievements";
import SaveLoadPanel from "@/components/SaveLoadPanel";

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isWobbling, setIsWobbling] = useState(false);
  const [wobbleIntensity, setWobbleIntensity] = useState(0.5);

  // Function to trigger wobble animation
  const triggerWobble = useCallback(() => {
    const dogeContainer = document.getElementById("ascii-doge-container");
    if (dogeContainer) {
      const event = new CustomEvent("wobble", {
        detail: { intensity: wobbleIntensity },
      });
      dogeContainer.dispatchEvent(event);
      setIsWobbling(true);

      // Announce to screen readers
      announceToScreenReader(
        `Doge is now wobbling with intensity at ${Math.round(wobbleIntensity * 100)}%`,
      );
    }
  }, [wobbleIntensity]);

  // Function to reset animation
  const resetDoge = useCallback(() => {
    const dogeContainer = document.getElementById("ascii-doge-container");
    if (dogeContainer) {
      const event = new CustomEvent("reset");
      dogeContainer.dispatchEvent(event);
      setIsWobbling(false);

      // Announce to screen readers
      announceToScreenReader("Animation has been reset");
    }
  }, []);

  // Function to handle intensity change
  const handleIntensityChange = useCallback(
    (intensity: number) => {
      setWobbleIntensity(intensity);

      // If already wobbling, update the intensity in real-time
      if (isWobbling) {
        const dogeContainer = document.getElementById("ascii-doge-container");
        if (dogeContainer) {
          const event = new CustomEvent("intensity-change", {
            detail: { intensity },
          });
          dogeContainer.dispatchEvent(event);

          // Announce significant changes to screen readers (in 25% increments)
          if (intensity % 0.25 < 0.05) {
            announceToScreenReader(
              `Wobble intensity set to ${Math.round(intensity * 100)}%`,
            );
          }
        }
      }
    },
    [isWobbling],
  );

  // Function to handle random personality change
  const handlePersonalityChange = useCallback(() => {
    const dogeContainer = document.getElementById("ascii-doge-container");
    if (dogeContainer) {
      const event = new CustomEvent("personality-change");
      dogeContainer.dispatchEvent(event);

      // Announce to screen readers after a slight delay to allow personality to be set
      setTimeout(() => {
        announceToScreenReader("Doge personality has changed");
      }, 100);
    }
  }, []);

  // Function to announce changes to screen readers
  const announceToScreenReader = (message: string) => {
    const announcement = document.getElementById("sr-announcement");
    if (announcement) {
      announcement.textContent = message;
    }
  };

  return (
    <div
      className="bg-[#F0E8DC] min-h-screen flex flex-col items-center justify-center overflow-hidden p-4"
      role="application"
      aria-label="Doge Clicker Game"
    >
      <Helmet>
        <title>Doge Clicker</title>
        <meta
          name="description"
          content="An interactive clicker game featuring ASCII art doge with wobbling effects, upgrades, and personalities"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@400;700&display=swap"
          rel="stylesheet"
        />
      </Helmet>

      {/* Visually hidden announcements for screen readers */}
      <div
        id="sr-announcement"
        role="status"
        aria-live="polite"
        className="sr-only"
      >
        {/* Content will be dynamically updated for screen reader announcements */}
      </div>

      {/* Header */}
      <header className="text-center mb-6">
        <h1
          className="text-4xl font-bold mb-2 text-[#5D534A]"
          style={{
            fontFamily:
              "'Comic Sans MS', 'Comic Neue', 'Chalkboard SE', sans-serif",
          }}
        >
          Doge Clicker
        </h1>
        <p
          className="text-lg text-[#8A7E6B]"
          style={{
            fontFamily:
              "'Comic Sans MS', 'Comic Neue', 'Chalkboard SE', sans-serif",
          }}
        >
          wow such click, very game
        </p>
        <p className="text-sm text-[#A69D8D] mt-2">
          Click on doge to earn points! Press ? key for keyboard shortcuts
        </p>
      </header>

      <div className="w-full max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Main game area */}
        <div className="md:col-span-2 flex flex-col items-center">
          {/* ASCII Art Doge */}
          <div
            id="ascii-doge-container"
            ref={containerRef}
            aria-label="ASCII art of Doge - Click to earn points"
            role="button"
            tabIndex={0}
            aria-atomic="true"
            aria-live="polite"
            className="my-4"
          >
            <AsciiDoge />
          </div>

          {/* Controls */}
          <Controls
            onWobble={triggerWobble}
            onReset={resetDoge}
            onIntensityChange={handleIntensityChange}
            onPersonalityChange={handlePersonalityChange}
            intensity={wobbleIntensity}
          />
        </div>

        {/* Upgrades and Achievements */}
        <div className="flex flex-col space-y-4">
          <UpgradeShop />
          <Achievements />
          <SaveLoadPanel />
        </div>
      </div>

      {/* Skip link for keyboard users - focuses the controls */}
      <a
        href="#keyboard-shortcuts"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:p-2 focus:bg-white focus:border focus:border-gray-300 focus:rounded"
      >
        Skip to controls
      </a>
    </div>
  );
}
import React, { createContext, useContext, useReducer, useEffect } from "react";
import {
  GameState,
  initialGameState,
  handleDogeClick,
  purchaseUpgrade,
  getPersonalityBonus,
  getPersonalityAutoClickBonus,
  checkAchievements,
} from "./gameUtils";

// Define our action types
export type GameAction =
  | { type: "CLICK"; personalityBonus?: number }
  | { type: "BUY_UPGRADE"; upgradeId: string }
  | {
      type: "BUY_PERSONALITY";
      personalityName: string;
      cost: number;
      showMinigame?: boolean;
    }
  | { type: "CHANGE_PERSONALITY"; personalityName: string | null }
  | { type: "AUTO_CLICK" }
  | { type: "UNLOCK_ACHIEVEMENT"; achievementId: string }
  | { type: "TOGGLE_ACHIEVEMENT_POPUPS" }
  | { type: "RESET_GAME" }
  | { type: "SAVE_GAME"; sessionId?: string }
  | { type: "LOAD_GAME"; sessionId: string }
  | { type: "SET_GAME_STATE"; state: GameState };

// Apply achievement rewards to game state
const applyAchievementRewards = (state: GameState): GameState => {
  // Get unlocked achievements
  const unlockedAchievements = state.achievements.filter((a) => a.unlocked);

  if (unlockedAchievements.length === 0) return state;

  let newState = { ...state };
  let clickPowerBonus = 0;
  let autoClickBonus = 0;
  let comboTimeBonus = 0;

  // Apply each achievement's reward
  unlockedAchievements.forEach((achievement) => {
    const { reward } = achievement;

    switch (reward.type) {
      case "clickPower":
        clickPowerBonus += reward.value;
        break;
      case "autoClick":
        autoClickBonus += reward.value;
        break;
      case "comboTime":
        comboTimeBonus += reward.value;
        break;
      // Other reward types are handled directly in click calculations
    }
  });

  // Update game state with achievement bonuses
  newState.clickPower = state.clickPower + clickPowerBonus;
  newState.autoClickRate = state.autoClickRate + autoClickBonus;
  newState.comboTimeWindow = state.comboTimeWindow + comboTimeBonus;

  return newState;
};

// Create our reducer function
const gameReducer = (state: GameState, action: GameAction): GameState => {
  let newState: GameState;

  switch (action.type) {
    case "CLICK":
      // Handle the click and get updated state
      newState = handleDogeClick(
        state,
        action.personalityBonus || state.personalityBonus,
      );

      // Check for new achievements after click
      const updatedAchievements = checkAchievements(newState);
      newState = {
        ...newState,
        achievements: updatedAchievements,
      };

      return newState;

    case "BUY_UPGRADE":
      // Purchase the upgrade
      newState = purchaseUpgrade(state, action.upgradeId);

      // Check for upgrade-related achievements
      const upgradeAchievements = checkAchievements(newState);
      newState = {
        ...newState,
        achievements: upgradeAchievements,
      };

      return newState;

    case "BUY_PERSONALITY":
      // Check if we can afford the personality
      if (state.score < action.cost) {
        return state; // Cannot afford
      }

      // Check if we already have this personality
      if (state.unlockedPersonalities.includes(action.personalityName)) {
        return state; // Already unlocked
      }

      // Add the personality to the purchase history
      const newPurchaseHistory = [
        ...state.personalityPurchaseHistory,
        action.personalityName,
      ];

      // Check for the secret GOD DOGE personality unlock
      // The correct order is: Curious, Chill, Sleepy, Wise, Silly, Hyper, Party
      const secretSequence = [
        "Curious",
        "Chill",
        "Sleepy",
        "Wise",
        "Silly",
        "Hyper",
        "Party",
      ];

      // Check if the last personalities purchased match the secret sequence
      let godDogeUnlocked = state.godDogeUnlocked;
      if (newPurchaseHistory.length >= secretSequence.length) {
        const lastPurchases = newPurchaseHistory.slice(-secretSequence.length);
        const isCorrectSequence = lastPurchases.every(
          (p, i) => p === secretSequence[i],
        );

        if (isCorrectSequence) {
          godDogeUnlocked = true;
        }
      }

      // Purchase the personality
      return {
        ...state,
        score: state.score - action.cost,
        unlockedPersonalities: [
          ...state.unlockedPersonalities,
          action.personalityName,
        ],
        personalityPurchaseHistory: newPurchaseHistory,
        godDogeUnlocked,
      };

    case "CHANGE_PERSONALITY":
      // Check if the personality is unlocked or null (default)
      if (
        action.personalityName !== null &&
        !state.unlockedPersonalities.includes(action.personalityName)
      ) {
        return state; // Personality not unlocked
      }

      const personalityBonus = getPersonalityBonus(action.personalityName);
      const autoClickBonus = getPersonalityAutoClickBonus(
        action.personalityName,
      );

      return {
        ...state,
        personalityBonus,
        currentPersonality: action.personalityName,
        autoClickRate: state.autoClickRate + autoClickBonus,
      };

    case "AUTO_CLICK":
      // Auto-click functions similar to a regular click but doesn't build combo
      if (state.autoClickRate > 0) {
        const clickPower = state.clickPower * state.personalityBonus;
        newState = {
          ...state,
          score: state.score + clickPower * state.autoClickRate,
        };

        // Check for score-based achievements from auto-clicks
        const autoClickAchievements = checkAchievements(newState);
        return {
          ...newState,
          achievements: autoClickAchievements,
        };
      }
      return state;

    case "UNLOCK_ACHIEVEMENT":
      // Find the achievement by ID
      const achievementIndex = state.achievements.findIndex(
        (a) => a.id === action.achievementId,
      );

      if (
        achievementIndex === -1 ||
        state.achievements[achievementIndex].unlocked
      ) {
        return state; // Achievement not found or already unlocked
      }

      // Create a new achievements array with the specified achievement unlocked
      const achievements = [...state.achievements];
      achievements[achievementIndex] = {
        ...achievements[achievementIndex],
        unlocked: true,
      };

      // Apply achievement rewards
      return {
        ...state,
        achievements,
      };

    case "TOGGLE_ACHIEVEMENT_POPUPS":
      return {
        ...state,
        settings: {
          ...state.settings,
          showAchievementPopups: !state.settings.showAchievementPopups,
        },
      };

    case "RESET_GAME":
      return initialGameState;

    case "SET_GAME_STATE":
      return action.state;

    case "SAVE_GAME":
      // Just return the current state - the actual saving logic is handled in the effect
      return state;

    case "LOAD_GAME":
      // Just return the current state - the actual loading logic is handled in the effect
      return state;

    default:
      return state;
  }
};

// Create our context
type GameContextType = {
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
};

const GameContext = createContext<GameContextType | undefined>(undefined);

// Game data API functions
const API_URL = "/api/player-data";

// Save game state to the server
export const saveGameState = async (
  state: GameState,
  sessionId?: string,
): Promise<string> => {
  try {
    // Prepare game data for saving
    const gameData = {
      sessionId:
        sessionId || localStorage.getItem("dogeSessionId") || undefined,
      score: state.score,
      clickPower: state.clickPower,
      autoClickRate: state.autoClickRate,
      personalityBonus: state.personalityBonus,
      currentPersonality: state.currentPersonality,
      unlockedPersonalities: state.unlockedPersonalities,
      personalityPurchaseHistory: state.personalityPurchaseHistory,
      godDogeUnlocked: state.godDogeUnlocked,
      upgrades: state.upgrades,
      achievements: state.achievements,
      comboTimeWindow: state.comboTimeWindow,
      highestCombo: state.highestCombo,
      showAchievementPopups: state.settings.showAchievementPopups,
    };

    // Check if we already have a session ID in local storage
    if (sessionId || localStorage.getItem("dogeSessionId")) {
      // Update existing game data
      const res = await fetch(`${API_URL}/${gameData.sessionId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(gameData),
      });

      if (!res.ok) {
        throw new Error("Failed to update game data");
      }

      const savedData = await res.json();
      return savedData.sessionId;
    } else {
      // Create new game data
      const res = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(gameData),
      });

      if (!res.ok) {
        throw new Error("Failed to save game data");
      }

      const savedData = await res.json();

      // Store the session ID in local storage
      localStorage.setItem("dogeSessionId", savedData.sessionId);

      return savedData.sessionId;
    }
  } catch (error) {
    console.error("Error saving game state:", error);
    throw error;
  }
};

// Load game state from the server
export const loadGameState = async (
  sessionId: string,
): Promise<GameState | null> => {
  try {
    const res = await fetch(`${API_URL}/${sessionId}`);

    if (!res.ok) {
      if (res.status === 404) {
        return null;
      }
      throw new Error("Failed to load game data");
    }

    const gameData = await res.json();

    // Convert the loaded data into a game state
    const loadedState: GameState = {
      score: gameData.score || 0,
      clickPower: gameData.clickPower || 1,
      autoClickRate: gameData.autoClickRate || 0,
      personalityBonus: gameData.personalityBonus || 1,
      currentPersonality: gameData.currentPersonality || null,
      unlockedPersonalities: gameData.unlockedPersonalities || [],
      personalityPurchaseHistory: gameData.personalityPurchaseHistory || [],
      godDogeUnlocked: gameData.godDogeUnlocked || false,
      upgrades: gameData.upgrades || initialGameState.upgrades,
      achievements: gameData.achievements || initialGameState.achievements,
      lastClickTime: 0, // Reset this value
      comboCount: 0, // Reset combo count
      comboTimeWindow: gameData.comboTimeWindow || 1000,
      highestCombo: gameData.highestCombo || 0,
      settings: {
        showAchievementPopups:
          gameData.showAchievementPopups !== undefined
            ? gameData.showAchievementPopups
            : true,
      },
    };

    return loadedState;
  } catch (error) {
    console.error("Error loading game state:", error);
    return null;
  }
};

// Create the provider component
export const GameProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [state, dispatch] = useReducer(gameReducer, initialGameState);

  // Auto-save game state at regular intervals
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      // Only auto-save if we have made progress (score > 0)
      if (state.score > 0) {
        saveGameState(state)
          .then((sessionId) => {
            console.log(`Game auto-saved with session ID: ${sessionId}`);
          })
          .catch((error) => {
            console.error("Auto-save failed:", error);
          });
      }
    }, 60000); // Auto-save every minute

    return () => clearInterval(autoSaveInterval);
  }, [state]);

  // Try to load saved game on initial mount
  useEffect(() => {
    const loadSavedGame = async () => {
      const savedSessionId = localStorage.getItem("dogeSessionId");

      if (savedSessionId) {
        try {
          const savedState = await loadGameState(savedSessionId);

          if (savedState) {
            dispatch({ type: "SET_GAME_STATE", state: savedState });
            console.log("Game state loaded successfully");
          }
        } catch (error) {
          console.error("Failed to load saved game:", error);
        }
      }
    };

    loadSavedGame();
  }, []);

  // Handle save and load actions
  useEffect(() => {
    const handleSaveLoadActions = async () => {
      // Create a copy of document.activeElement to avoid bugs with focus
      const activeElement = document.activeElement;

      try {
        // Find recent actions in the action queue
        const recentActions = (window as any).__gameActions || [];
        const saveAction = recentActions.find(
          (a: any) => a.type === "SAVE_GAME",
        );
        const loadAction = recentActions.find(
          (a: any) => a.type === "LOAD_GAME",
        );

        if (saveAction) {
          await saveGameState(state, saveAction.sessionId);
          console.log("Game saved manually");
        }

        if (loadAction) {
          const loadedState = await loadGameState(loadAction.sessionId);
          if (loadedState) {
            dispatch({ type: "SET_GAME_STATE", state: loadedState });
            console.log("Game loaded manually");
          }
        }
      } catch (error) {
        console.error("Error handling save/load:", error);
      } finally {
        // Clear action queue
        (window as any).__gameActions = [];

        // Restore focus
        if (activeElement && "focus" in activeElement) {
          (activeElement as HTMLElement).focus();
        }
      }
    };

    // Create a global action queue if it doesn't exist
    if (!(window as any).__gameActions) {
      (window as any).__gameActions = [];
    }

    handleSaveLoadActions();
  }, [state]);

  // Set up auto-clicking
  useEffect(() => {
    if (state.autoClickRate <= 0) return;

    const interval = setInterval(() => {
      dispatch({ type: "AUTO_CLICK" });
    }, 1000); // Auto-click once per second

    return () => clearInterval(interval);
  }, [state.autoClickRate]);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
};

// Create a hook for easy context usage
export const useGame = (): GameContextType => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error("useGame must be used within a GameProvider");
  }
  return context;
}; // Game mechanics utilities and types for the doge clicker game

export interface GameSettings {
  showAchievementPopups: boolean;
}

export interface GameState {
  score: number;
  clickPower: number;
  autoClickRate: number;
  personalityBonus: number;
  currentPersonality: string | null;
  unlockedPersonalities: string[];
  // Track the personality purchase history for secret unlock
  personalityPurchaseHistory: string[];
  // Flag for tracking if GOD DOGE has been unlocked
  godDogeUnlocked: boolean;
  upgrades: Upgrade[];
  achievements: Achievement[];
  lastClickTime: number;
  comboCount: number;
  comboTimeWindow: number; // time window in ms for combo clicks
  highestCombo: number;
  settings: GameSettings;
}

export interface Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  level: number;
  maxLevel: number;
  clickPowerBonus: number;
  autoClickBonus: number;
  comboBonus: number;
  icon: string;
  unlocked: boolean;
  purchased: boolean;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  requirement: {
    type: "score" | "clicks" | "combo" | "personalities" | "upgrades";
    value: number;
  };
  reward: {
    type:
      | "none"
      | "clickPower"
      | "autoClick"
      | "comboTime"
      | "comboMultiplier"
      | "clickMultiplier";
    value: number;
  };
}

// Initial upgrades available in the game
export const initialUpgrades: Upgrade[] = [
  {
    id: "treat",
    name: "Tasty Treats",
    description: "Give doge treats to increase click power",
    cost: 50,
    level: 0,
    maxLevel: 10,
    clickPowerBonus: 1,
    autoClickBonus: 0,
    comboBonus: 0,
    icon: "🦴",
    unlocked: true,
    purchased: false,
  },
  {
    id: "toy",
    name: "Bouncy Toy",
    description: "A fun toy that makes doge more excited",
    cost: 200,
    level: 0,
    maxLevel: 5,
    clickPowerBonus: 5,
    autoClickBonus: 0,
    comboBonus: 0.1,
    icon: "🎾",
    unlocked: true,
    purchased: false,
  },
  {
    id: "autoclicker",
    name: "Auto Petter",
    description: "Automatically pets doge every few seconds",
    cost: 500,
    level: 0,
    maxLevel: 10,
    clickPowerBonus: 0,
    autoClickBonus: 1,
    comboBonus: 0,
    icon: "🖐️",
    unlocked: false,
    purchased: false,
  },
  {
    id: "friend",
    name: "Doge Friend",
    description: "A friend for your doge, doubles click power",
    cost: 1000,
    level: 0,
    maxLevel: 3,
    clickPowerBonus: 10,
    autoClickBonus: 2,
    comboBonus: 0.2,
    icon: "🐕",
    unlocked: false,
    purchased: false,
  },
  {
    id: "bed",
    name: "Comfy Doge Bed",
    description: "A comfortable bed for doge to rest and gain energy",
    cost: 2500,
    level: 0,
    maxLevel: 3,
    clickPowerBonus: 5,
    autoClickBonus: 3,
    comboBonus: 0,
    icon: "🛏️",
    unlocked: false,
    purchased: false,
  },
  {
    id: "costume",
    name: "Doggo Costume",
    description: "Stylish outfit that makes doge feel fancy",
    cost: 3500,
    level: 0,
    maxLevel: 3,
    clickPowerBonus: 25,
    autoClickBonus: 0,
    comboBonus: 0.5,
    icon: "👕",
    unlocked: false,
    purchased: false,
  },
  {
    id: "rainbow",
    name: "Rainbow Power",
    description: "Harness the power of rainbow colors",
    cost: 5000,
    level: 0,
    maxLevel: 1,
    clickPowerBonus: 50,
    autoClickBonus: 5,
    comboBonus: 0.5,
    icon: "🌈",
    unlocked: false,
    purchased: false,
  },
  {
    id: "spaceship",
    name: "Doge to the Moon",
    description: "Dogecoin reference! To the moon!",
    cost: 15000,
    level: 0,
    maxLevel: 1,
    clickPowerBonus: 100,
    autoClickBonus: 10,
    comboBonus: 2,
    icon: "🚀",
    unlocked: false,
    purchased: false,
  },
  {
    id: "timetravel",
    name: "Time Traveling Doge",
    description: "Paradoxical powers from the future!",
    cost: 50000,
    level: 0,
    maxLevel: 1,
    clickPowerBonus: 500,
    autoClickBonus: 20,
    comboBonus: 5,
    icon: "⏰",
    unlocked: false,
    purchased: false,
  },
  {
    id: "wizard",
    name: "Wizard Doge",
    description: "Magical powers for ultra clicking",
    cost: 100000,
    level: 0,
    maxLevel: 1,
    clickPowerBonus: 1000,
    autoClickBonus: 50,
    comboBonus: 10,
    icon: "🧙",
    unlocked: false,
    purchased: false,
  },
];

// Initial achievements available in the game
export const initialAchievements: Achievement[] = [
  // Common achievements (score-based)
  {
    id: "first_click",
    name: "First Click",
    description:
      "Click on doge for the first time. Every journey begins with a single click!",
    icon: "👆",
    unlocked: false,
    requirement: {
      type: "score",
      value: 1,
    },
    reward: {
      type: "none",
      value: 0,
    },
  },
  {
    id: "click_10",
    name: "Click Apprentice",
    description: "Reach 10 clicks. You're getting the hang of this!",
    icon: "🐕",
    unlocked: false,
    requirement: {
      type: "score",
      value: 10,
    },
    reward: {
      type: "clickPower",
      value: 1,
    },
  },
  {
    id: "click_50",
    name: "Dedicated Clicker",
    description:
      "Reach 50 clicks. Your dedication to doge clicking is commendable.",
    icon: "🖱️",
    unlocked: false,
    requirement: {
      type: "score",
      value: 50,
    },
    reward: {
      type: "clickPower",
      value: 2,
    },
  },

  // Uncommon achievements
  {
    id: "click_100",
    name: "Click Master",
    description:
      "Reach 100 clicks. You've mastered the basic art of doge clicking!",
    icon: "🏆",
    unlocked: false,
    requirement: {
      type: "score",
      value: 100,
    },
    reward: {
      type: "clickPower",
      value: 5,
    },
  },
  {
    id: "click_500",
    name: "Click Enthusiast",
    description:
      "Reach 500 clicks. Your enthusiasm for doge clicking is truly impressive!",
    icon: "🎯",
    unlocked: false,
    requirement: {
      type: "score",
      value: 500,
    },
    reward: {
      type: "comboTime",
      value: 500, // +500ms to combo time window
    },
  },

  // Rare achievements
  {
    id: "click_1000",
    name: "Click Champion",
    description:
      "Reach 1,000 clicks. You've achieved champion status in the doge clicking world!",
    icon: "👑",
    unlocked: false,
    requirement: {
      type: "score",
      value: 1000,
    },
    reward: {
      type: "clickPower",
      value: 10,
    },
  },
  {
    id: "click_5000",
    name: "Click Virtuoso",
    description:
      "Reach 5,000 clicks. Your clicking skills are approaching virtuoso levels!",
    icon: "🌟",
    unlocked: false,
    requirement: {
      type: "score",
      value: 5000,
    },
    reward: {
      type: "autoClick",
      value: 1,
    },
  },

  // Epic achievements
  {
    id: "click_10000",
    name: "Click Legend",
    description:
      "Reach 10,000 clicks. Your legendary status in doge clicking will be remembered for generations!",
    icon: "⭐",
    unlocked: false,
    requirement: {
      type: "score",
      value: 10000,
    },
    reward: {
      type: "clickPower",
      value: 25,
    },
  },

  // Legendary achievements
  {
    id: "click_50000",
    name: "Click God",
    description:
      "Reach 50,000 clicks. You have ascended to godhood in the realm of doge clicking!",
    icon: "✨",
    unlocked: false,
    requirement: {
      type: "score",
      value: 50000,
    },
    reward: {
      type: "clickMultiplier",
      value: 2, // 2x multiplier
    },
  },

  // Combo achievements
  {
    id: "combo_5",
    name: "Quick Fingers",
    description: "Get a 5x click combo. Your fingers are nimble!",
    icon: "👐",
    unlocked: false,
    requirement: {
      type: "combo",
      value: 5,
    },
    reward: {
      type: "comboTime",
      value: 100, // +100ms to combo time window
    },
  },
  {
    id: "combo_10",
    name: "Combo Novice",
    description:
      "Get a 10x click combo. You're developing a rhythm to your clicking!",
    icon: "🔥",
    unlocked: false,
    requirement: {
      type: "combo",
      value: 10,
    },
    reward: {
      type: "comboTime",
      value: 200, // +200ms to combo time window
    },
  },
  {
    id: "combo_25",
    name: "Combo Master",
    description:
      "Get a 25x click combo. Your clicking speed is becoming legendary!",
    icon: "⚡",
    unlocked: false,
    requirement: {
      type: "combo",
      value: 25,
    },
    reward: {
      type: "clickPower",
      value: 5,
    },
  },
  {
    id: "combo_50",
    name: "Combo King",
    description:
      "Get a 50x click combo. Your fingers move faster than the eye can see!",
    icon: "🌪️",
    unlocked: false,
    requirement: {
      type: "combo",
      value: 50,
    },
    reward: {
      type: "comboMultiplier",
      value: 1.5, // 1.5x combo multiplier
    },
  },

  // Upgrade achievements
  {
    id: "first_upgrade",
    name: "Upgrader",
    description:
      "Purchase your first upgrade. This is just the beginning of your doge's journey!",
    icon: "🛒",
    unlocked: false,
    requirement: {
      type: "upgrades",
      value: 1,
    },
    reward: {
      type: "none",
      value: 0,
    },
  },
  {
    id: "five_upgrades",
    name: "Doge Enhancer",
    description:
      "Purchase 5 different upgrades. Your doge is becoming more powerful!",
    icon: "🔧",
    unlocked: false,
    requirement: {
      type: "upgrades",
      value: 5,
    },
    reward: {
      type: "clickPower",
      value: 5,
    },
  },
  {
    id: "all_upgrades",
    name: "Maximized Doge",
    description:
      "Purchase all available upgrades. Your doge has reached its final form!",
    icon: "🌈",
    unlocked: false,
    requirement: {
      type: "upgrades",
      value: 10,
    },
    reward: {
      type: "clickMultiplier",
      value: 1.5, // 1.5x multiplier
    },
  },
];

// Initial game state
export const initialGameState: GameState = {
  score: 0,
  clickPower: 1,
  autoClickRate: 0,
  personalityBonus: 1,
  currentPersonality: null,
  unlockedPersonalities: [],
  personalityPurchaseHistory: [], // Track the order of personality purchases
  godDogeUnlocked: false, // Secret GOD DOGE personality unlock status
  upgrades: initialUpgrades,
  achievements: initialAchievements,
  lastClickTime: 0,
  comboCount: 0,
  comboTimeWindow: 1000, // 1 second window for combos
  highestCombo: 0,
  settings: {
    showAchievementPopups: true,
  },
};

// Calculate the current click power based on upgrades and bonuses
export const calculateClickPower = (state: GameState): number => {
  let power = state.clickPower;

  // Add upgrade bonuses
  state.upgrades.forEach((upgrade) => {
    if (upgrade.purchased && upgrade.level > 0) {
      power += upgrade.clickPowerBonus * upgrade.level;
    }
  });

  // Apply achievement bonuses
  let clickMultiplier = 1;
  let comboMultiplierBonus = 0;

  state.achievements.forEach((achievement) => {
    if (achievement.unlocked && achievement.reward) {
      if (achievement.reward.type === "clickMultiplier") {
        // Multiply the total click power
        clickMultiplier *= achievement.reward.value;
      } else if (achievement.reward.type === "comboMultiplier") {
        // Increase the combo multiplier effect
        comboMultiplierBonus += achievement.reward.value - 1;
      }
    }
  });

  // Apply personality bonus
  power *= state.personalityBonus;

  // Apply combo bonus (10% extra per combo, up to 2x + achievement bonuses)
  const comboBonus = 0.1;
  const maxComboMultiplier = 2 + comboMultiplierBonus;
  const comboMultiplier = Math.min(
    maxComboMultiplier,
    1 + state.comboCount * comboBonus,
  );
  power *= comboMultiplier;

  // Apply overall click multiplier from achievements
  power *= clickMultiplier;

  // Ensure the click power is always a whole number
  return Math.round(power);
};

// Calculate the cost of the next upgrade level
export const calculateUpgradeCost = (upgrade: Upgrade): number => {
  return Math.floor(upgrade.cost * Math.pow(1.5, upgrade.level));
};

// Check if the player can afford an upgrade
export const canAffordUpgrade = (
  state: GameState,
  upgradeId: string,
): boolean => {
  const upgrade = state.upgrades.find((u) => u.id === upgradeId);
  if (!upgrade) return false;

  const cost = calculateUpgradeCost(upgrade);
  return state.score >= cost && upgrade.level < upgrade.maxLevel;
};

// Purchase an upgrade
export const purchaseUpgrade = (
  state: GameState,
  upgradeId: string,
): GameState => {
  const upgrades = [...state.upgrades];
  const upgradeIndex = upgrades.findIndex((u) => u.id === upgradeId);

  if (upgradeIndex === -1) return state;

  const upgrade = { ...upgrades[upgradeIndex] };
  const cost = calculateUpgradeCost(upgrade);

  if (state.score < cost || upgrade.level >= upgrade.maxLevel) {
    return state;
  }

  // Update the upgrade
  upgrade.level += 1;
  upgrade.purchased = true;
  upgrades[upgradeIndex] = upgrade;

  // Update game state
  const newScore = state.score - cost;
  const newClickPower = state.clickPower + upgrade.clickPowerBonus;
  const newAutoClickRate = state.autoClickRate + upgrade.autoClickBonus;

  // Unlock new upgrades based on score
  const newUpgrades = upgrades.map((u) => {
    if (!u.unlocked) {
      if (
        (u.id === "autoclicker" && newScore >= 300) ||
        (u.id === "friend" && newScore >= 800) ||
        (u.id === "bed" && newScore >= 1500) ||
        (u.id === "costume" && newScore >= 2500) ||
        (u.id === "rainbow" && newScore >= 3000) ||
        (u.id === "spaceship" && newScore >= 8000) ||
        (u.id === "timetravel" && newScore >= 25000) ||
        (u.id === "wizard" && newScore >= 70000)
      ) {
        return { ...u, unlocked: true };
      }
    }
    return u;
  });

  return {
    ...state,
    score: newScore,
    clickPower: newClickPower,
    autoClickRate: newAutoClickRate,
    upgrades: newUpgrades,
  };
};

// Handle a click on the doge
export const handleDogeClick = (
  state: GameState,
  personalityBonus: number = 1,
): GameState => {
  const now = Date.now();
  let comboCount = state.comboCount;

  // Check if this click is part of a combo
  if (now - state.lastClickTime < state.comboTimeWindow) {
    comboCount += 1;
  } else {
    comboCount = 1; // Reset combo if too much time has passed
  }

  // Update highest combo if applicable
  const highestCombo = Math.max(state.highestCombo, comboCount);

  // Calculate click value based on power and combos
  const clickPower = calculateClickPower({
    ...state,
    comboCount,
    personalityBonus,
  });
  const newScore = state.score + clickPower;

  // Check for new achievements
  const newAchievements = checkAchievements({
    ...state,
    score: newScore,
    comboCount,
    highestCombo,
  });

  // Check if we should unlock new upgrades
  const newUpgrades = checkUpgradeUnlocks({
    ...state,
    score: newScore,
    achievements: newAchievements,
  });

  return {
    ...state,
    score: newScore,
    lastClickTime: now,
    comboCount,
    highestCombo,
    personalityBonus,
    achievements: newAchievements,
    upgrades: newUpgrades,
  };
};

// Check for new achievements based on the current game state
export const checkAchievements = (state: GameState): Achievement[] => {
  return state.achievements.map((achievement) => {
    if (achievement.unlocked) return achievement;

    let unlocked = false;

    switch (achievement.requirement.type) {
      case "score":
        unlocked = state.score >= achievement.requirement.value;
        break;
      case "combo":
        unlocked = state.highestCombo >= achievement.requirement.value;
        break;
      case "upgrades":
        unlocked =
          state.upgrades.filter((u) => u.purchased).length >=
          achievement.requirement.value;
        break;
    }

    return unlocked ? { ...achievement, unlocked: true } : achievement;
  });
};

// Check if new upgrades should be unlocked based on score
export const checkUpgradeUnlocks = (state: GameState): Upgrade[] => {
  // Unlock upgrades based on score milestones
  const scoreLevels = [
    0, 100, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000,
  ];

  let playerLevel = 1;
  for (let i = 0; i < scoreLevels.length; i++) {
    if (state.score >= scoreLevels[i]) {
      playerLevel = i + 1; // Player level starts at 1
    } else {
      break;
    }
  }

  // Unlock upgrades based on player level
  const newUpgrades = [...state.upgrades].map((upgrade) => {
    if (!upgrade.unlocked) {
      if (
        (upgrade.id === "autoclicker" && playerLevel >= 2) ||
        (upgrade.id === "friend" && playerLevel >= 3) ||
        (upgrade.id === "bed" && playerLevel >= 4) ||
        (upgrade.id === "costume" && playerLevel >= 4) ||
        (upgrade.id === "rainbow" && playerLevel >= 5) ||
        (upgrade.id === "spaceship" && playerLevel >= 6) ||
        (upgrade.id === "timetravel" && playerLevel >= 8) ||
        (upgrade.id === "wizard" && playerLevel >= 9)
      ) {
        return { ...upgrade, unlocked: true };
      }
    }
    return upgrade;
  });

  return newUpgrades;
};

// Format numbers for display (e.g. 1,234 or 1.2K)
export const formatNumber = (num: number): string => {
  if (num < 1000) return num.toString();
  if (num < 1000000) return `${(num / 1000).toFixed(1)}K`;
  return `${(num / 1000000).toFixed(1)}M`;
};

// Calculate personality bonus based on personality traits
export const getPersonalityBonus = (personalityName: string | null): number => {
  if (!personalityName) return 1;

  switch (personalityName) {
    case "Hyper":
      return 1.5; // 50% bonus for hyper personality
    case "Party":
      return 1.3; // 30% bonus for party personality
    case "Curious":
      return 1.2; // 20% bonus for curious personality
    case "Silly":
      return 1.25; // 25% bonus for silly personality
    case "Wise":
      return 1.15; // 15% bonus for wise personality
    case "Chill":
      return 0.9; // 10% penalty for chill personality (but auto-click bonus)
    case "Sleepy":
      return 0.8; // 20% penalty for sleepy personality (but auto-click bonus)
    case "GOD DOGE":
      return 10; // 1000% bonus for secret GOD DOGE personality - CHEAT MODE!
    default:
      return 1;
  }
};

// Get auto-click rate bonus from personality
export const getPersonalityAutoClickBonus = (
  personalityName: string | null,
): number => {
  if (!personalityName) return 0;

  switch (personalityName) {
    case "Chill":
      return 1; // Chill gives auto-clicks to compensate for click penalty
    case "Sleepy":
      return 2; // Sleepy gives more auto-clicks to compensate for click penalty
    case "GOD DOGE":
      return 5; // GOD DOGE gives 5 auto-clicks per second as part of cheat mode
    default:
      return 0;
  }
}; // Doge personality traits system

// Personality trait types and descriptions
export interface DogePersonalityTrait {
  name: string;
  description: string;
  emoji: string;
  // How it affects color cycling and wobbling
  colorEffect?: {
    saturation?: number; // 0-100%
    brightness?: number; // 0-100%
    cycleSpeed?: number; // Multiplier for cycle speed
    colorPalette?: string[]; // Custom colors for this personality
  };
  wobbleEffect?: {
    intensity?: number; // Multiplier for wobble intensity
    frequency?: number; // Multiplier for wobble frequency
    amplitude?: number; // Multiplier for wobble amplitude
  };
  soundEffect?: string; // Future implementation for sound effects
  catchphrase?: string[]; // Doge catchphrases related to this trait
}

// Secret personality trait - unlocked through special sequence
export const secretPersonalityTrait: DogePersonalityTrait = {
  name: "GOD DOGE",
  description: "ULTRA BUFF! Such muscle! Much strength! Many power!",
  emoji: "💪",
  colorEffect: {
    saturation: 120,
    brightness: 110,
    cycleSpeed: 2.0,
    colorPalette: [
      "#FFD700",
      "#FF8C00",
      "#FF1493",
      "#DA70D6",
      "#00FFFF",
      "#00FF00",
    ], // Rainbow of vibrant colors
  },
  wobbleEffect: {
    intensity: 1.5,
    frequency: 1.8,
    amplitude: 1.7,
  },
  catchphrase: [
    "SUCH MUSCLES",
    "VERY POWERFUL",
    "MUCH STRENGTH",
    "WOW UNLIMITED",
    "SO GODLIKE",
  ],
};

// Available personality traits
export const personalityTraits: DogePersonalityTrait[] = [
  {
    name: "Hyper",
    description: "Such energy! Very excitement!",
    emoji: "⚡",
    colorEffect: {
      saturation: 100,
      brightness: 100,
      cycleSpeed: 1.5,
      colorPalette: [
        "#FF0000",
        "#FF3300",
        "#FF6600",
        "#FF9900",
        "#FFCC00",
        "#FFFF00",
      ], // Hot reds and yellows
    },
    wobbleEffect: {
      intensity: 1.3,
      frequency: 1.4,
      amplitude: 1.2,
    },
    catchphrase: ["much energy", "very speed", "so hyper", "wow zoom"],
  },
  {
    name: "Chill",
    description: "So relax. Much calm.",
    emoji: "😌",
    colorEffect: {
      saturation: 70,
      brightness: 90,
      cycleSpeed: 0.8,
      colorPalette: [
        "#66CCFF",
        "#99CCFF",
        "#CCCCFF",
        "#CCFFFF",
        "#99FFCC",
        "#66FFCC",
      ], // Cool blues and teals
    },
    wobbleEffect: {
      intensity: 0.7,
      frequency: 0.8,
      amplitude: 0.9,
    },
    catchphrase: ["so relax", "much calm", "very zen", "wow peace"],
  },
  {
    name: "Silly",
    description: "Much laugh! So random!",
    emoji: "🤪",
    colorEffect: {
      saturation: 90,
      brightness: 95,
      cycleSpeed: 1.2,
      colorPalette: [
        "#FF66FF",
        "#FF99CC",
        "#FFCC99",
        "#CCFF00",
        "#FF6600",
        "#9933FF",
      ], // Random crazy colors
    },
    wobbleEffect: {
      intensity: 1.1,
      frequency: 1.0,
      amplitude: 1.3,
    },
    catchphrase: ["much silly", "so random", "very goof", "wow laugh"],
  },
  {
    name: "Curious",
    description: "Such wonder! Many questions!",
    emoji: "🧐",
    colorEffect: {
      saturation: 85,
      brightness: 90,
      cycleSpeed: 1.0,
      colorPalette: [
        "#FFB347",
        "#FFCC99",
        "#FFDB58",
        "#E6C35C",
        "#EADDCA",
        "#FFE5B4",
      ], // Amber and gold tones
    },
    wobbleEffect: {
      intensity: 0.9,
      frequency: 1.1,
      amplitude: 1.0,
    },
    catchphrase: [
      "much wonder",
      "such question",
      "very puzzle",
      "wow discovery",
    ],
  },
  {
    name: "Sleepy",
    description: "So tired. Much yawn.",
    emoji: "😴",
    colorEffect: {
      saturation: 60,
      brightness: 80,
      cycleSpeed: 0.6,
      colorPalette: [
        "#7B68EE",
        "#9370DB",
        "#8A2BE2",
        "#9966CC",
        "#CCCCFF",
        "#DCD0FF",
      ], // Lavender and purple shades
    },
    wobbleEffect: {
      intensity: 0.6,
      frequency: 0.7,
      amplitude: 0.7,
    },
    catchphrase: ["such tired", "very sleepy", "much yawn", "wow dreams"],
  },
  {
    name: "Party",
    description: "Such fun! Very celebration!",
    emoji: "🎉",
    colorEffect: {
      saturation: 100,
      brightness: 100,
      cycleSpeed: 1.6,
      colorPalette: [
        "#FF69B4",
        "#EE82EE",
        "#FF1493",
        "#00FFFF",
        "#00FF00",
        "#F4A460",
      ], // Neon party colors
    },
    wobbleEffect: {
      intensity: 1.4,
      frequency: 1.3,
      amplitude: 1.5,
    },
    catchphrase: [
      "much party",
      "so celebration",
      "very festive",
      "wow confetti",
    ],
  },
  {
    name: "Wise",
    description: "Much knowledge. Very wisdom.",
    emoji: "🧙",
    colorEffect: {
      saturation: 75,
      brightness: 85,
      cycleSpeed: 0.7,
      colorPalette: [
        "#4682B4",
        "#5F9EA0",
        "#008080",
        "#008B8B",
        "#00CED1",
        "#00FFFF",
      ], // Deep blues and teals
    },
    wobbleEffect: {
      intensity: 0.8,
      frequency: 0.6,
      amplitude: 0.7,
    },
    catchphrase: [
      "such wisdom",
      "very insight",
      "much knowledge",
      "wow enlighten",
    ],
  },
];

// Function to get a random personality trait
export const getRandomPersonalityTrait = (): DogePersonalityTrait => {
  const randomIndex = Math.floor(Math.random() * personalityTraits.length);
  return personalityTraits[randomIndex];
};

// Function to get random catchphrases for a trait
export const getRandomCatchphrase = (trait: DogePersonalityTrait): string => {
  if (!trait.catchphrase || trait.catchphrase.length === 0) {
    return "wow. such doge. much amaze.";
  }
  const randomIndex = Math.floor(Math.random() * trait.catchphrase.length);
  return trait.catchphrase[randomIndex];
};

// Get 2-3 random catchphrases for a speech bubble
export const getRandomCatchphrases = (
  trait: DogePersonalityTrait,
  count: number = 3,
): string[] => {
  const phrases: string[] = [];

  // Always include "wow" at least once
  phrases.push("wow");

  // Add specific trait catchphrases
  if (trait.catchphrase && trait.catchphrase.length > 0) {
    const availablePhrases = [...trait.catchphrase];
    for (let i = 0; i < count - 1 && availablePhrases.length > 0; i++) {
      const randomIndex = Math.floor(Math.random() * availablePhrases.length);
      phrases.push(availablePhrases[randomIndex]);
      availablePhrases.splice(randomIndex, 1); // Remove used phrase
    }
  }

  // Add generic catchphrases if needed
  const genericPhrases = ["such doge", "much amaze", "very cool", "so wow"];
  while (phrases.length < count) {
    const randomIndex = Math.floor(Math.random() * genericPhrases.length);
    phrases.push(genericPhrases[randomIndex]);
  }

  return phrases;
};
import React, { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DogePersonalityTrait,
  getRandomPersonalityTrait,
  personalityTraits,
  secretPersonalityTrait,
} from "../lib/dogePersonality";
import { useGame } from "../lib/GameContext";
import { getPersonalityBonus } from "../lib/gameUtils";
import SpeechBubble from "./SpeechBubble";
import buffDogeImage from "@assets/buff-doge.svg";

// Map of personality names to their primary colors
const personalityBaseColors = {
  Hyper: "#FF3300", // Bright orange-red for energy
  Chill: "#66CCFF", // Soft blue for calmness
  Silly: "#FF66FF", // Pink for silliness
  Curious: "#FFB347", // Amber for curiosity
  Sleepy: "#9370DB", // Purple for sleepiness
  Party: "#FF1493", // Deep pink for party
  Wise: "#4682B4", // Steel blue for wisdom
  "GOD DOGE": "#FFD700", // Gold for ultimate power
  Default: "#F2C94C", // Default doge color
};

const AsciiDoge: React.FC = () => {
  const { state, dispatch } = useGame();
  const [isWobbling, setIsWobbling] = useState(false);
  const [currentColor, setCurrentColor] = useState("#F2C94C"); // Initial color (yellow/gold)
  const colorIntervalRef = useRef<number | null>(null);
  const rainbowIntervalRef = useRef<number | null>(null);
  const [clickAnimations, setClickAnimations] = useState<
    { id: number; x: number; y: number; value: number }[]
  >([]);
  const nextAnimationId = useRef(0);

  const [personalityColors, setPersonalityColors] = useState<string[]>([
    "#FF0000",
    "#FF7F00",
    "#FFFF00",
    "#00FF00",
    "#0000FF",
    "#4B0082",
    "#9400D3",
  ]); // Default rainbow colors

  // State for wobble intensity
  const [wobbleIntensity, setWobbleIntensity] = useState(0.5);
  // State for personality
  const [personality, setPersonality] = useState<DogePersonalityTrait | null>(
    null,
  );
  const [showSpeechBubble, setShowSpeechBubble] = useState(false);

  // The ASCII art is stored as a string with the exact spacing preserved
  const asciiArt = `        ▄               ▄    
        ▌▒█           ▄▀▒▌   
        ▌▒▒█        ▄▀▒▒▒▐   
       ▐▄█▒▒▀▀▀▀▄▄▄▀▒▒▒▒▒▐   
     ▄▄▀▒▒▒▒▒▒▒▒▒▒▒█▒▒▄█▒▐   
   ▄▀▒▒▒░░░▒▒▒░░░▒▒▒▀██▀▒▌   
  ▐▒▒▒▄▄▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▀▄▒▌  
  ▌░░▌█▀▒▒▒▒▒▄▀█▄▒▒▒▒▒▒▒█▒▐  
 ▐░░░▒▒▒▒▒▒▒▒▌██▀▒▒░░░▒▒▒▀▄▌ 
 ▌░▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░▒▒▒▒▌ 
▌▒▒▒▄██▄▒▒▒▒▒▒▒▒░░░░░░░░▒▒▒▐ 
▐▒▒▐▄█▄█▌▒▒▒▒▒▒▒▒▒▒░▒░▒░▒▒▒▒▌
▐▒▒▐▀▐▀▒▒▒▒▒▒▒▒▒▒▒▒▒░▒░▒░▒▒▐ 
 ▌▒▒▀▄▄▄▄▄▄▀▒▒▒▒▒▒▒░▒░▒░▒▒▒▌ 
 ▐▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░▒░▒▒▄▒▒▐  
  ▀▄▒▒▒▒▒▒░▒▒▒▒▒▒▒▒░▒▄▒▒▒▒▌`;

  // Stop rainbow cycle function (defined first to avoid circular dependency)
  const stopRainbowCycle = useCallback(() => {
    if (rainbowIntervalRef.current) {
      window.clearInterval(rainbowIntervalRef.current);
      rainbowIntervalRef.current = null;
    }
  }, []);

  // Rainbow cycle for when no personality is assigned
  const startRainbowCycle = useCallback(() => {
    // Clear any existing rainbow interval
    stopRainbowCycle();

    let colorIndex = 0;
    const rainbowColors = [
      "#FF0000", // Red
      "#FF7F00", // Orange
      "#FFFF00", // Yellow
      "#00FF00", // Green
      "#0000FF", // Blue
      "#4B0082", // Indigo
      "#9400D3", // Violet
    ];

    rainbowIntervalRef.current = window.setInterval(() => {
      setCurrentColor(rainbowColors[colorIndex]);
      colorIndex = (colorIndex + 1) % rainbowColors.length;
    }, 2000); // Slower fade through colors when idle
  }, [stopRainbowCycle]);

  // Color cycle for wobbling with personality-based colors
  const startColorCycle = useCallback(() => {
    if (colorIntervalRef.current) {
      window.clearInterval(colorIntervalRef.current);
    }

    let colorIndex = 0;

    // Calculate color change interval based on intensity and personality
    // Higher intensity = faster color changes (200ms at max, 800ms at min)
    let baseInterval = Math.max(200, 800 - wobbleIntensity * 600);

    // Apply personality cycle speed adjustment if available
    if (personality && personality.colorEffect?.cycleSpeed) {
      baseInterval = baseInterval / personality.colorEffect.cycleSpeed;
    }

    // Ensure interval is reasonable
    const colorChangeInterval = Math.max(100, Math.min(1000, baseInterval));

    colorIntervalRef.current = window.setInterval(() => {
      setCurrentColor(personalityColors[colorIndex]);
      colorIndex = (colorIndex + 1) % personalityColors.length;
    }, colorChangeInterval);
  }, [wobbleIntensity, personality, personalityColors]);

  // Stop color cycle and set appropriate static color
  const stopColorCycle = useCallback(() => {
    if (colorIntervalRef.current) {
      window.clearInterval(colorIntervalRef.current);
      colorIntervalRef.current = null;
    }

    // Set color based on personality or default
    if (personality) {
      setCurrentColor(
        personalityBaseColors[
          personality.name as keyof typeof personalityBaseColors
        ] || "#F2C94C",
      );
    } else {
      // If no personality is assigned, start the rainbow cycle
      startRainbowCycle();
    }
  }, [personality, startRainbowCycle]);

  // Listen for wobble event and intensity changes
  useEffect(() => {
    const container = document.getElementById("ascii-doge-container");

    if (container) {
      const handleWobbleEvent = (event: Event) => {
        // Stop rainbow cycle if active
        stopRainbowCycle();

        // Get intensity from event if available
        const customEvent = event as CustomEvent;
        const intensity = customEvent.detail?.intensity || wobbleIntensity;

        // Update intensity
        setWobbleIntensity(intensity);

        // Start wobbling indefinitely
        setIsWobbling(true);

        // Start rainbow color cycle
        startColorCycle();
      };

      const handleResetEvent = () => {
        // Stop wobbling
        setIsWobbling(false);

        // Stop color cycle
        stopColorCycle();
      };

      const handleIntensityChange = (event: Event) => {
        const customEvent = event as CustomEvent;
        const intensity = customEvent.detail?.intensity || wobbleIntensity;

        // Update intensity in real-time
        setWobbleIntensity(intensity);

        // If already wobbling, restart the color cycle with the new timing
        if (isWobbling) {
          // Stop current cycle
          if (colorIntervalRef.current) {
            window.clearInterval(colorIntervalRef.current);
          }
          // Restart with new interval
          startColorCycle();
        }
      };

      // Handle personality changes
      const handlePersonalityChange = () => {
        // Stop rainbow cycle first (if active)
        stopRainbowCycle();

        // Get all unlocked personalities from game state
        const { unlockedPersonalities } = state;

        if (unlockedPersonalities.length === 0) {
          // No personalities unlocked yet, set to default (null)
          dispatch({ type: "CHANGE_PERSONALITY", personalityName: null });
          setPersonality(null);

          // Start rainbow cycle for default mode
          startRainbowCycle();
          return;
        }

        // Get a random personality from unlocked ones
        const randomIndex = Math.floor(
          Math.random() * unlockedPersonalities.length,
        );
        const randomPersonalityName = unlockedPersonalities[randomIndex];

        // Find the personality trait object
        const newPersonality = personalityTraits.find(
          (p: DogePersonalityTrait) => p.name === randomPersonalityName,
        );

        if (!newPersonality) {
          console.warn(
            `Could not find personality trait for ${randomPersonalityName}`,
          );
          return;
        }

        setPersonality(newPersonality);

        // Update game context with personality bonus
        dispatch({
          type: "CHANGE_PERSONALITY",
          personalityName: newPersonality.name,
        });

        // Immediately update color to personality base color
        const baseColor =
          personalityBaseColors[
            newPersonality.name as keyof typeof personalityBaseColors
          ] || personalityBaseColors.Default;
        setCurrentColor(baseColor);

        // Set personality-specific color palette if available
        if (newPersonality.colorEffect?.colorPalette) {
          setPersonalityColors(newPersonality.colorEffect.colorPalette);
        } else {
          // Default rainbow palette
          setPersonalityColors([
            "#FF0000", // Red
            "#FF7F00", // Orange
            "#FFFF00", // Yellow
            "#00FF00", // Green
            "#0000FF", // Blue
            "#4B0082", // Indigo
            "#9400D3", // Violet
          ]);
        }

        // Apply personality effects to wobble if a personality has intensity effects
        if (newPersonality.wobbleEffect?.intensity) {
          // Adjust intensity based on personality (clamped between 0.1 and 1)
          const newIntensity = Math.min(
            1,
            Math.max(
              0.1,
              wobbleIntensity * newPersonality.wobbleEffect.intensity,
            ),
          );
          setWobbleIntensity(newIntensity);

          // If already wobbling, apply the new intensity
          if (isWobbling) {
            // Create a custom event with the new intensity
            const intensityEvent = new CustomEvent("intensity-change", {
              detail: { intensity: newIntensity },
            });
            container.dispatchEvent(intensityEvent);
          }
        }

        // Show speech bubble with catchphrases
        setShowSpeechBubble(false);
        // Force re-render to get a new catchphrase
        setTimeout(() => {
          setShowSpeechBubble(true);

          // Hide speech bubble after 10 seconds
          setTimeout(() => {
            setShowSpeechBubble(false);
          }, 10000);
        }, 50);
      };

      // Listen for personality-change event
      const handlePersonalityChangeEvent = () => {
        handlePersonalityChange();
      };

      // Handle selecting a specific personality
      const handlePersonalitySelect = (event: Event) => {
        const customEvent = event as CustomEvent;
        const selectedPersonality = customEvent.detail?.personality;

        if (selectedPersonality) {
          const personalityName = selectedPersonality.name;

          // Check if it's null (default) or an unlocked personality
          const { unlockedPersonalities } = state;
          const isUnlocked = unlockedPersonalities.includes(personalityName);

          if (!isUnlocked && personalityName !== null) {
            console.warn(
              `Attempted to select locked personality: ${personalityName}`,
            );
            return; // Cannot select a locked personality
          }

          // If personality is null, reset to default
          if (personalityName === null) {
            // Stop rainbow cycle first (if active)
            stopRainbowCycle();
            setPersonality(null);

            // Update game context
            dispatch({
              type: "CHANGE_PERSONALITY",
              personalityName: null,
            });

            // Start rainbow cycle for default mode
            startRainbowCycle();
            return;
          }

          // Stop rainbow cycle first (if active)
          stopRainbowCycle();

          setPersonality(selectedPersonality);

          // Update game context with personality bonus
          dispatch({
            type: "CHANGE_PERSONALITY",
            personalityName: selectedPersonality.name,
          });

          // Immediately update color to personality base color
          const baseColor =
            personalityBaseColors[
              selectedPersonality.name as keyof typeof personalityBaseColors
            ] || personalityBaseColors.Default;
          setCurrentColor(baseColor);

          // Set personality-specific color palette if available
          if (selectedPersonality.colorEffect?.colorPalette) {
            setPersonalityColors(selectedPersonality.colorEffect.colorPalette);
          } else {
            // Default rainbow palette
            setPersonalityColors([
              "#FF0000", // Red
              "#FF7F00", // Orange
              "#FFFF00", // Yellow
              "#00FF00", // Green
              "#0000FF", // Blue
              "#4B0082", // Indigo
              "#9400D3", // Violet
            ]);
          }

          // Apply personality effects to wobble if a personality has intensity effects
          if (selectedPersonality.wobbleEffect?.intensity) {
            // Adjust intensity based on personality (clamped between 0.1 and 1)
            const newIntensity = Math.min(
              1,
              Math.max(
                0.1,
                wobbleIntensity * selectedPersonality.wobbleEffect.intensity,
              ),
            );
            setWobbleIntensity(newIntensity);

            // If already wobbling, apply the new intensity
            if (isWobbling) {
              // Create a custom event with the new intensity
              const intensityEvent = new CustomEvent("intensity-change", {
                detail: { intensity: newIntensity },
              });
              container.dispatchEvent(intensityEvent);
            }
          }

          // Show speech bubble with catchphrases
          setShowSpeechBubble(false);
          // Force re-render to get a new catchphrase
          setTimeout(() => {
            setShowSpeechBubble(true);

            // Hide speech bubble after 10 seconds
            setTimeout(() => {
              setShowSpeechBubble(false);
            }, 10000);
          }, 50);
        }
      };

      container.addEventListener(
        "personality-change",
        handlePersonalityChangeEvent,
      );
      container.addEventListener("personality-select", handlePersonalitySelect);
      container.addEventListener("wobble", handleWobbleEvent);
      container.addEventListener("reset", handleResetEvent);
      container.addEventListener("intensity-change", handleIntensityChange);

      return () => {
        container.removeEventListener(
          "personality-change",
          handlePersonalityChangeEvent,
        );
        container.removeEventListener(
          "personality-select",
          handlePersonalitySelect,
        );
        container.removeEventListener("wobble", handleWobbleEvent);
        container.removeEventListener("reset", handleResetEvent);
        container.removeEventListener(
          "intensity-change",
          handleIntensityChange,
        );
        stopColorCycle();
      };
    }
  }, [
    wobbleIntensity,
    isWobbling,
    personality,
    personalityColors,
    startColorCycle,
    stopColorCycle,
    stopRainbowCycle,
    dispatch,
  ]);

  // Start a rainbow fade when no personality is assigned (initial load)
  useEffect(() => {
    // Start rainbow cycle if no personality is set
    if (!personality && !isWobbling) {
      startRainbowCycle();
    }

    return () => {
      stopRainbowCycle();
    };
  }, [personality, isWobbling, startRainbowCycle, stopRainbowCycle]);

  // Cleanup on component unmount
  useEffect(() => {
    return () => {
      if (colorIntervalRef.current) {
        window.clearInterval(colorIntervalRef.current);
      }
      if (rainbowIntervalRef.current) {
        window.clearInterval(rainbowIntervalRef.current);
      }
    };
  }, []);

  // Get dynamic animation values based on intensity
  const getIntensityValues = (base: number, intensity: number) => {
    return base * intensity * 2; // Scale based on intensity
  };

  // Generate dynamic wobble animation based on intensity
  const generateWobbleVariants = (intensity: number) => {
    // Base amplitude values
    const baseRotate = 8;
    const baseX = 20;
    const baseY = 5;
    const baseScale = 0.05;

    // Calculate intensity-adjusted values
    const rotateVal = getIntensityValues(baseRotate, intensity);
    const xVal = getIntensityValues(baseX, intensity);
    const yVal = getIntensityValues(baseY, intensity);
    const scaleIncrease = baseScale * intensity;

    return {
      idle: {
        rotate: 0,
        x: 0,
        y: 0,
        scale: 1,
      },
      wobble: {
        // Enhanced wobble animation - faster and smoother
        rotate: [
          -rotateVal,
          -rotateVal * 0.5,
          0,
          rotateVal * 0.5,
          rotateVal,
          rotateVal * 0.5,
          0,
          -rotateVal * 0.5,
          -rotateVal,
        ],
        x: [
          -xVal,
          -xVal * 0.6,
          -xVal * 0.2,
          xVal * 0.2,
          xVal,
          xVal * 0.6,
          xVal * 0.2,
          -xVal * 0.2,
          -xVal,
        ],
        y: [
          0,
          -yVal * 0.3,
          -yVal,
          -yVal * 0.6,
          0,
          -yVal * 0.3,
          -yVal,
          -yVal * 0.6,
          0,
        ],
        scale: [
          1,
          1 + scaleIncrease * 0.5,
          1 + scaleIncrease,
          1 + scaleIncrease * 0.7,
          1,
          1 + scaleIncrease * 0.5,
          1 + scaleIncrease,
          1 + scaleIncrease * 0.7,
          1,
        ],
        transition: {
          // Faster animation with smoother transitions
          duration: 1.8 - wobbleIntensity * 1.2, // Range from 0.6s (high intensity) to 1.7s (low intensity)
          ease: "linear", // Continuous smooth motion
          times: [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1],
          repeat: Infinity, // Wobble infinitely
          repeatType: "loop" as const,
          repeatDelay: 0, // No delay between iterations
        },
      },
    };
  };

  // Handle doge click for the clicker game
  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Get the rect of the target to calculate click position relative to the element
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Dispatch click to game state
    const personalityBonus = personality
      ? getPersonalityBonus(personality.name)
      : 1;
    dispatch({ type: "CLICK", personalityBonus });

    // Start wobbling
    setIsWobbling(true);

    // Show the animation at click position
    const clickValue = Math.round(state.clickPower * personalityBonus);
    const id = nextAnimationId.current++;

    // Add the new animation
    setClickAnimations((prev) => [...prev, { id, x, y, value: clickValue }]);

    // Remove the animation after animation completes
    setTimeout(() => {
      setClickAnimations((prev) => prev.filter((anim) => anim.id !== id));
    }, 1000);

    // Start color cycling
    startColorCycle();

    // Reset state after 5 seconds of no activity
    const resetTimer = setTimeout(() => {
      setIsWobbling(false);
      stopColorCycle();
    }, 5000);

    // Clear previous timeout if exists
    return () => clearTimeout(resetTimer);
  };

  // Continuous wobble animation variants based on intensity
  const wobbleVariants = generateWobbleVariants(wobbleIntensity);

  return (
    <div
      className="max-w-xs md:max-w-sm mx-auto relative cursor-pointer"
      aria-busy={isWobbling}
      aria-describedby={
        isWobbling ? "doge-status-wobbling" : "doge-status-idle"
      }
      onClick={handleClick}
    >
      {/* Click value animations */}
      <AnimatePresence>
        {clickAnimations.map(({ id, x, y, value }) => (
          <motion.div
            key={id}
            initial={{ opacity: 1, y: 0, x: 0 }}
            animate={{ opacity: 0, y: -50, x: Math.random() * 40 - 20 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="absolute font-bold text-yellow-500 text-shadow-md pointer-events-none z-10"
            style={{
              left: x,
              top: y,
              textShadow: "0 1px 2px rgba(0,0,0,0.5)",
              fontSize: Math.min(24, 16 + Math.log(value) * 2),
            }}
          >
            +{value}
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Speech bubble for personality */}
      <SpeechBubble personality={personality} isVisible={showSpeechBubble} />

      {/* Hidden descriptions for screen readers */}
      <div id="doge-status-wobbling" className="sr-only">
        Doge is wobbling with rainbow color effects
        {personality && ` with ${personality.name} personality`}
      </div>
      <div id="doge-status-idle" className="sr-only">
        Doge is standing still
        {personality && ` with ${personality.name} personality`}
      </div>

      {/* Personality indicator */}
      {personality && (
        <div
          className="absolute top-0 left-0 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1 shadow-md"
          style={{
            background: `linear-gradient(to right, ${personalityBaseColors[personality.name as keyof typeof personalityBaseColors] || "#F2C94C"}, ${(personality.colorEffect?.colorPalette && personality.colorEffect.colorPalette[1]) || "#FF7F00"})`,
            color:
              personality.name === "Chill" || personality.name === "Sleepy"
                ? "#000"
                : "#fff",
          }}
        >
          <span>{personality.emoji}</span>
          <span className="font-bold">{personality.name}</span>

          {/* Show personality bonus if applicable */}
          {personality && getPersonalityBonus(personality.name) !== 1 && (
            <span className="text-xs font-normal ml-1">
              {getPersonalityBonus(personality.name) > 1
                ? `+${Math.round((getPersonalityBonus(personality.name) - 1) * 100)}%`
                : `${Math.round((getPersonalityBonus(personality.name) - 1) * 100)}%`}
            </span>
          )}
        </div>
      )}

      <motion.div
        animate={isWobbling ? "wobble" : "idle"}
        variants={wobbleVariants}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        transition={{ type: "spring", stiffness: 300, damping: 15 }}
        tabIndex={0}
        role="button"
        aria-label={`Click the doge to earn points${personality ? ` (${personality.name} personality)` : ""}`}
        className="select-none"
      >
        {personality && personality.name === secretPersonalityTrait.name ? (
          <img
            src={buffDogeImage}
            alt="GOD DOGE"
            className="max-w-full h-auto mx-auto"
            style={{
              filter: `hue-rotate(${Math.random() * 360}deg) saturate(${personality.colorEffect?.saturation || 100}%)`,
              transition: "filter 0.5s ease",
              width: "80%",
              margin: "0 auto",
            }}
          />
        ) : (
          <pre
            className="font-mono text-xs sm:text-sm md:text-base select-none"
            style={{
              lineHeight: 1.2,
              textShadow: "1px 1px 2px rgba(0,0,0,0.1)",
              fontFamily: "monospace",
              color: currentColor,
              transition: "color 1s ease-in-out",
            }}
            aria-hidden="true" // Hide the actual ASCII art from screen readers
          >
            {asciiArt}
          </pre>
        )}
      </motion.div>
    </div>
  );
};

export default AsciiDoge;
import { Button } from "@/components/ui/button";
import { DOGE_COLORS } from "@/lib/utils";
import { useEffect, useState } from "react";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Shuffle, RotateCcw, ShoppingCart, Bell } from "lucide-react";
import { personalityTraits } from "../lib/dogePersonality";
import { useGame } from "../lib/GameContext";
import {
  formatNumber,
  getPersonalityBonus,
  getPersonalityAutoClickBonus,
} from "../lib/gameUtils";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ControlsProps {
  onWobble: () => void;
  onReset: () => void;
  onIntensityChange?: (value: number) => void;
  onPersonalityChange?: () => void;
  intensity?: number;
}

const Controls = ({
  onWobble,
  onReset,
  onIntensityChange = () => {},
  onPersonalityChange = () => {},
  intensity = 0.5,
}: ControlsProps) => {
  const { state, dispatch } = useGame();
  const [keyboardShortcutsVisible, setKeyboardShortcutsVisible] =
    useState(false);
  const [currentIntensity, setCurrentIntensity] = useState(intensity);

  // Handle keyboard events for accessibility
  // Handle intensity change
  const handleIntensityChange = (values: number[]) => {
    const value = values[0];
    setCurrentIntensity(value);
    onIntensityChange(value);
  };

  // Update slider when intensity prop changes
  useEffect(() => {
    setCurrentIntensity(intensity);
  }, [intensity]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Space or W key to wobble
      if (event.key === " " || event.key.toLowerCase() === "w") {
        onWobble();
        event.preventDefault(); // Prevent page scroll on spacebar
      }
      // Escape or R key to reset
      else if (event.key === "Escape" || event.key.toLowerCase() === "r") {
        onReset();
      }
      // Show/hide keyboard shortcuts with ? key
      else if (event.key === "?") {
        setKeyboardShortcutsVisible((prev) => !prev);
      }
      // P key to change personality
      else if (event.key.toLowerCase() === "p") {
        onPersonalityChange();
        event.preventDefault();
      }
      // Arrow up/right to increase intensity
      else if (event.key === "ArrowUp" || event.key === "ArrowRight") {
        const newValue = Math.min(1, currentIntensity + 0.1);
        setCurrentIntensity(newValue);
        onIntensityChange(newValue);
        event.preventDefault();
      }
      // Arrow down/left to decrease intensity
      else if (event.key === "ArrowDown" || event.key === "ArrowLeft") {
        const newValue = Math.max(0.1, currentIntensity - 0.1);
        setCurrentIntensity(newValue);
        onIntensityChange(newValue);
        event.preventDefault();
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    // Clean up event listener
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [
    onWobble,
    onReset,
    currentIntensity,
    onIntensityChange,
    onPersonalityChange,
  ]);

  return (
    <Card className="mt-4 overflow-hidden bg-[#F0E8DC] border-[#DDD6CA]">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg text-[#5D534A]">
          Doge Clicker Controls
        </CardTitle>
        <CardDescription className="text-[#8A7E6B]">
          Customize your doge and upgrade your clicking power
        </CardDescription>
      </CardHeader>

      <CardContent className="p-4">
        <Tabs defaultValue="personalities" className="w-full">
          <TabsList className="w-full grid grid-cols-2">
            <TabsTrigger value="personalities">Personalities</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="personalities" className="mt-4">
            <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Doge Personalities
              <span className="text-xs text-gray-500 ml-2">
                (each personality has different click bonuses)
              </span>
            </div>
            <div className="flex flex-wrap gap-2 justify-center">
              {personalityTraits.map((trait) => {
                // Get bonus info for displaying
                const personalityName = trait.name;
                let bonusText = "";

                if (personalityName === "Hyper") bonusText = "+50% clicks";
                if (personalityName === "Party") bonusText = "+30% clicks";
                if (personalityName === "Curious") bonusText = "+20% clicks";
                if (personalityName === "Silly") bonusText = "+25% clicks";
                if (personalityName === "Wise") bonusText = "+15% clicks";
                if (personalityName === "Chill") bonusText = "+1 auto-click";
                if (personalityName === "Sleepy") bonusText = "+2 auto-clicks";

                // Check if this personality is unlocked
                const isUnlocked =
                  state.unlockedPersonalities.includes(personalityName);
                const isSelected = state.currentPersonality === personalityName;

                return (
                  <TooltipProvider key={trait.name}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant={isSelected ? "default" : "outline"}
                          size="sm"
                          className={`flex flex-col items-center gap-1 h-auto py-2 relative
                            ${isUnlocked ? "" : "opacity-60 grayscale"}
                            ${isSelected ? "ring-2 ring-amber-400 ring-offset-2" : ""}
                          `}
                          style={{
                            fontFamily:
                              "'Comic Sans MS', 'Chalkboard SE', sans-serif",
                          }}
                          onClick={() => {
                            if (!isUnlocked) return; // Cannot select if not unlocked

                            // Change to this personality
                            dispatch({
                              type: "CHANGE_PERSONALITY",
                              personalityName: trait.name,
                            });
                          }}
                          disabled={!isUnlocked}
                          aria-label={`Set doge personality to ${trait.name}`}
                        >
                          <span className="text-lg">{trait.emoji}</span>
                          <span>{trait.name}</span>
                          {bonusText && (
                            <span className="text-xs opacity-75">
                              {bonusText}
                            </span>
                          )}
                          {!isUnlocked && (
                            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                              🔒
                            </span>
                          )}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{trait.description}</p>
                        {getPersonalityBonus(trait.name) > 1 && (
                          <p className="text-green-500">
                            +
                            {Math.round(
                              (getPersonalityBonus(trait.name) - 1) * 100,
                            )}
                            % click power
                          </p>
                        )}
                        {getPersonalityBonus(trait.name) < 1 && (
                          <p className="text-red-500">
                            {Math.round(
                              (getPersonalityBonus(trait.name) - 1) * 100,
                            )}
                            % click power
                          </p>
                        )}
                        {getPersonalityAutoClickBonus(trait.name) > 0 && (
                          <p className="text-blue-500">
                            +{getPersonalityAutoClickBonus(trait.name)} auto
                            clicks/sec
                          </p>
                        )}
                        {!isUnlocked && (
                          <p className="border-t border-gray-200 mt-2 pt-2 text-amber-600">
                            Purchase this personality in the shop!
                          </p>
                        )}
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                );
              })}
            </div>

            <div className="text-center mt-4">
              <Button
                onClick={() => {
                  // Switch to default (no personality)
                  dispatch({
                    type: "CHANGE_PERSONALITY",
                    personalityName: null,
                  });
                }}
                variant="outline"
                className="bg-gradient-to-r from-gray-400 to-gray-500 hover:from-gray-500 hover:to-gray-600 text-white font-bold rounded transition-colors shadow-md flex items-center gap-2 mx-auto"
                style={{
                  fontFamily: "'Comic Sans MS', 'Chalkboard SE', sans-serif",
                }}
                aria-label="Reset personality"
              >
                <RotateCcw className="h-4 w-4" />
                Reset Personality
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="mt-4 space-y-4">
            {/* Wobble Intensity Slider */}
            <div className="w-full mb-4">
              <div className="flex justify-between items-center mb-2">
                <Label
                  htmlFor="wobble-intensity"
                  className="text-sm font-medium"
                  style={{
                    fontFamily: "'Comic Sans MS', 'Chalkboard SE', sans-serif",
                  }}
                >
                  Wobble Intensity
                </Label>
                <Badge variant="secondary">
                  {Math.round(currentIntensity * 100)}%
                </Badge>
              </div>

              <div className="relative">
                <Slider
                  id="wobble-intensity"
                  min={0.1}
                  max={1}
                  step={0.05}
                  value={[currentIntensity]}
                  onValueChange={handleIntensityChange}
                  className="w-full"
                  aria-label="Adjust wobble intensity"
                  aria-valuemin={0.1}
                  aria-valuemax={1}
                  aria-valuenow={currentIntensity}
                  aria-valuetext={`Intensity: ${Math.round(currentIntensity * 100)}%`}
                />
                <div className="flex justify-between mt-1 text-xs text-gray-500">
                  <span>Gentle</span>
                  <span>Wild</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 justify-center">
              <Button
                onClick={onWobble}
                className="bg-[#F2C94C] hover:bg-[#F2994A] text-white font-bold rounded transition-colors shadow-md"
                style={{
                  fontFamily: "'Comic Sans MS', 'Chalkboard SE', sans-serif",
                }}
                aria-label="Start wobbling animation"
              >
                WOBBLE!
              </Button>
              <Button
                onClick={onReset}
                variant="secondary"
                className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold rounded transition-colors shadow-md"
                style={{
                  fontFamily: "'Comic Sans MS', 'Chalkboard SE', sans-serif",
                }}
                aria-label="Reset animation"
              >
                Reset
              </Button>
              <Button
                onClick={() => dispatch({ type: "RESET_GAME" })}
                variant="destructive"
                className="font-bold flex items-center gap-1"
                style={{
                  fontFamily: "'Comic Sans MS', 'Chalkboard SE', sans-serif",
                }}
                aria-label="Reset game progress"
              >
                <RotateCcw className="h-4 w-4" />
                Reset Game
              </Button>
            </div>

            {/* Game Notification Settings */}
            <div className="w-full p-3 border border-gray-200 rounded-md">
              <h3
                className="text-sm font-medium mb-2"
                style={{
                  fontFamily: "'Comic Sans MS', 'Chalkboard SE', sans-serif",
                }}
              >
                Game Settings
              </h3>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Bell className="h-4 w-4 text-amber-500" />
                  <Label
                    htmlFor="achievement-notifications"
                    className="text-sm cursor-pointer"
                  >
                    Show Achievement Pop-ups
                  </Label>
                </div>
                <Switch
                  id="achievement-notifications"
                  checked={state.settings.showAchievementPopups}
                  onCheckedChange={() =>
                    dispatch({ type: "TOGGLE_ACHIEVEMENT_POPUPS" })
                  }
                  aria-label="Toggle achievement notifications"
                />
              </div>
            </div>

            <div className="text-xs text-gray-500 dark:text-gray-400 text-center mt-2 p-2 bg-gray-50 dark:bg-gray-800 rounded">
              <div className="font-bold mb-1">Game Stats</div>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-left">Total Clicks:</div>
                <div className="text-right font-medium">
                  {formatNumber(state.score)}
                </div>
                <div className="text-left">Click Power:</div>
                <div className="text-right font-medium">
                  {formatNumber(state.clickPower)}/click
                </div>
                <div className="text-left">Auto-clicks:</div>
                <div className="text-right font-medium">
                  {formatNumber(state.autoClickRate)}/sec
                </div>
                <div className="text-left">Personalities:</div>
                <div className="text-right font-medium">
                  {state.unlockedPersonalities.length}/
                  {personalityTraits.length}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <button
          onClick={() => setKeyboardShortcutsVisible((prev) => !prev)}
          className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1 mt-4 bg-transparent border-none cursor-pointer mx-auto"
          aria-expanded={keyboardShortcutsVisible}
          aria-controls="keyboard-shortcuts"
        >
          <span className="sr-only">Toggle keyboard shortcuts</span>
          <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
            ?
          </kbd>
          <span>Keyboard shortcuts</span>
        </button>

        {keyboardShortcutsVisible && (
          <div
            id="keyboard-shortcuts"
            className="mt-3 p-3 bg-gray-50 rounded-md shadow-sm text-sm border border-gray-200"
            role="region"
            aria-label="Keyboard shortcuts"
          >
            <ul className="text-left m-0 p-0 list-none space-y-2">
              <li className="flex items-center gap-2">
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  Space
                </kbd>
                <span>or</span>
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  W
                </kbd>
                <span>Start wobbling</span>
              </li>
              <li className="flex items-center gap-2">
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  Esc
                </kbd>
                <span>or</span>
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  R
                </kbd>
                <span>Reset animation</span>
              </li>
              <li className="flex items-center gap-2">
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  P
                </kbd>
                <span>Change doge personality</span>
              </li>
              <li className="flex items-center gap-2">
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  ←
                </kbd>
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  ↓
                </kbd>
                <span>Decrease intensity</span>
              </li>
              <li className="flex items-center gap-2">
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  →
                </kbd>
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  ↑
                </kbd>
                <span>Increase intensity</span>
              </li>
              <li className="flex items-center gap-2">
                <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs">
                  ?
                </kbd>
                <span>Show/hide shortcuts</span>
              </li>
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default Controls;
import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import DogeSegment from "./DogeSegment";
import { PHYSICS } from "@/lib/utils";
import useWobble from "@/hooks/useWobble";

interface LongDogeProps {
  onWobble: () => void;
}

const LongDoge = ({ onWobble }: LongDogeProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
  const { segments, handleMouseMove, triggerWobble, resetDoge } =
    useWobble(containerSize);

  // Handle window resize
  useEffect(() => {
    const updateContainerSize = () => {
      if (containerRef.current) {
        setContainerSize({
          width: containerRef.current.offsetWidth,
          height: containerRef.current.offsetHeight,
        });
      }
    };

    // Initial size update
    updateContainerSize();

    // Add resize event listener
    window.addEventListener("resize", updateContainerSize);

    // Initialize doge after setting container size
    return () => {
      window.removeEventListener("resize", updateContainerSize);
    };
  }, []);

  // Reset doge when container size changes
  useEffect(() => {
    if (containerSize.width > 0 && containerSize.height > 0) {
      resetDoge();
    }
  }, [containerSize, resetDoge]);

  // Listen for wobble and reset events
  useEffect(() => {
    const container = document.getElementById("doge-container");

    if (container) {
      const handleWobbleEvent = () => {
        triggerWobble();
      };

      const handleResetEvent = () => {
        resetDoge();
      };

      container.addEventListener("wobble", handleWobbleEvent);
      container.addEventListener("reset", handleResetEvent);

      return () => {
        container.removeEventListener("wobble", handleWobbleEvent);
        container.removeEventListener("reset", handleResetEvent);
      };
    }
  }, [triggerWobble, resetDoge]);

  const handleDogeClick = () => {
    triggerWobble();
    onWobble();
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full max-w-3xl h-60 sm:h-80 md:h-96 flex items-center justify-center cursor-pointer"
      onMouseMove={(e) => {
        if (containerRef.current) {
          const rect = containerRef.current.getBoundingClientRect();
          handleMouseMove(e.clientX - rect.left, e.clientY - rect.top);
        }
      }}
      onTouchMove={(e) => {
        e.preventDefault();
        if (containerRef.current && e.touches[0]) {
          const rect = containerRef.current.getBoundingClientRect();
          const touch = e.touches[0];
          handleMouseMove(touch.clientX - rect.left, touch.clientY - rect.top);
        }
      }}
      onClick={handleDogeClick}
      onTouchEnd={handleDogeClick}
    >
      {segments.map((segment, index) => (
        <DogeSegment
          key={index}
          isHead={index === 0}
          isTail={index === PHYSICS.SEGMENTS - 1}
          width={segment.width}
          height={segment.height}
          x={segment.x - segment.width / 2}
          y={segment.y - segment.height / 2}
          rotation={segment.rotation}
          index={index}
          zIndex={PHYSICS.SEGMENTS - index}
        />
      ))}
    </div>
  );
};

export default LongDoge;
import { motion } from "framer-motion";
import { useRef, useEffect } from "react";
import { DOGE_COLORS } from "@/lib/utils";

interface DogeSegmentProps {
  isHead?: boolean;
  isTail?: boolean;
  width: number;
  height: number;
  x: number;
  y: number;
  rotation: number;
  index: number;
  zIndex: number;
}

const DogeSegment = ({
  isHead = false,
  isTail = false,
  width,
  height,
  x,
  y,
  rotation,
  index,
  zIndex,
}: DogeSegmentProps) => {
  const segmentRef = useRef<HTMLDivElement>(null);

  // Basic segment styles
  const segmentClasses = `absolute border-2 border-[${DOGE_COLORS.dark}] bg-[${DOGE_COLORS.primary}] shadow-md`;

  // Apply rounded corners based on segment position
  const roundedClasses = isHead
    ? "rounded-full"
    : isTail
      ? "rounded-r-full"
      : "";

  // Head features (eyes, nose, mouth)
  if (isHead) {
    return (
      <motion.div
        ref={segmentRef}
        className={`${segmentClasses} ${roundedClasses}`}
        style={{
          width,
          height,
          x,
          y,
          rotate: 0, // Head doesn't rotate
          zIndex,
        }}
        initial={{ x, y }}
        animate={{ x, y }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      >
        {/* Left eye */}
        <div
          className="absolute bg-[#4F4F4F] rounded-full"
          style={{ width: 10, height: 10, top: 25, left: 20 }}
        />
        {/* Right eye */}
        <div
          className="absolute bg-[#4F4F4F] rounded-full"
          style={{ width: 10, height: 10, top: 25, right: 20 }}
        />
        {/* Nose */}
        <div
          className="absolute bg-black rounded-full"
          style={{
            width: 12,
            height: 8,
            top: 35,
            left: "50%",
            transform: "translateX(-50%)",
          }}
        />
        {/* Mouth */}
        <div
          className="absolute bg-[#4F4F4F]"
          style={{
            width: 20,
            height: 6,
            borderTopLeftRadius: "10px",
            borderTopRightRadius: "10px",
            borderBottomLeftRadius: "20px",
            borderBottomRightRadius: "20px",
            top: 45,
            left: "50%",
            transform: "translateX(-50%)",
          }}
        />
      </motion.div>
    );
  }

  // Body segment or tail
  return (
    <motion.div
      ref={segmentRef}
      className={`${segmentClasses} ${roundedClasses}`}
      style={{
        width,
        height,
        x,
        y,
        zIndex,
      }}
      initial={{ x, y, rotate: 0 }}
      animate={{ x, y, rotate: rotation }}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
    />
  );
};

export default DogeSegment;
import React, { useState } from "react";
import { useGame } from "../lib/GameContext";
import {
  canAffordUpgrade,
  calculateUpgradeCost,
  formatNumber,
  getPersonalityBonus,
  getPersonalityAutoClickBonus,
} from "../lib/gameUtils";
import {
  personalityTraits,
  secretPersonalityTrait,
} from "../lib/dogePersonality";
import GodDogeMinigame from "./GodDogeMinigame";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./ui/tooltip";
import { motion } from "framer-motion";
import { ShoppingCart, Award, Zap } from "lucide-react";

// Define personality prices
const PERSONALITY_PRICES = {
  Hyper: 1500,
  Party: 1200,
  Curious: 1000,
  Silly: 1200,
  Wise: 800,
  Chill: 1500,
  Sleepy: 2000,
  "GOD DOGE": 1000000, // 1 million clicks for the secret GOD DOGE personality
};

// Late game upgrades cost multiplier
const LATE_GAME_MULTIPLIER = 3;

const UpgradeShop: React.FC = () => {
  const { state, dispatch } = useGame();
  const { upgrades, score, unlockedPersonalities, godDogeUnlocked } = state;
  const [activeTab, setActiveTab] = useState<string>("upgrades");
  const [showGodDogeMinigame, setShowGodDogeMinigame] = useState(false);

  const handleBuyUpgrade = (upgradeId: string) => {
    dispatch({ type: "BUY_UPGRADE", upgradeId });
  };

  const handleBuyPersonality = (personalityName: string, cost: number) => {
    if (personalityName === "GOD DOGE") {
      // Show the minigame when GOD DOGE is purchased
      dispatch({ type: "BUY_PERSONALITY", personalityName, cost });
      setShowGodDogeMinigame(true);
    } else {
      dispatch({ type: "BUY_PERSONALITY", personalityName, cost });
    }
  };

  // Filter to only show unlocked upgrades
  const availableUpgrades = upgrades.filter((upgrade) => upgrade.unlocked);

  return (
    <>
      {showGodDogeMinigame && (
        <GodDogeMinigame onClose={() => setShowGodDogeMinigame(false)} />
      )}

      <Card className="w-full bg-[#F0E8DC] border-[#DDD6CA]">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg text-[#5D534A]">Upgrade Shop</CardTitle>
          <CardDescription className="text-[#8A7E6B]">
            Improve your doge's powers and personalities
          </CardDescription>
        </CardHeader>

        <CardContent className="p-4">
          <Tabs
            defaultValue="upgrades"
            value={activeTab}
            onValueChange={setActiveTab}
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="upgrades" className="flex items-center gap-1">
                <Zap className="h-4 w-4" />
                <span>Upgrades</span>
              </TabsTrigger>
              <TabsTrigger
                value="personalities"
                className="flex items-center gap-1"
              >
                <Award className="h-4 w-4" />
                <span>Personalities</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="upgrades" className="mt-4">
              {availableUpgrades.length === 0 ? (
                <div className="text-center py-4 text-gray-500">
                  No upgrades available yet. Keep clicking!
                </div>
              ) : (
                <div className="space-y-3">
                  {availableUpgrades.map((upgrade) => {
                    // Increase late-game upgrade costs (level > 5) by 3x
                    const baseCost = calculateUpgradeCost(upgrade);
                    const cost =
                      upgrade.level > 5
                        ? baseCost * LATE_GAME_MULTIPLIER
                        : baseCost;
                    const canAfford = score >= cost;
                    // No level limits on upgrades anymore
                    const isMaxLevel = false;

                    return (
                      <motion.div
                        key={upgrade.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ type: "spring", damping: 20 }}
                        whileHover={{ scale: 1.02 }}
                      >
                        <Card
                          className={`relative overflow-hidden ${isMaxLevel ? "bg-gray-100 dark:bg-gray-800" : canAfford ? "bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-900/20 dark:to-yellow-900/10" : "bg-gray-50 dark:bg-gray-900"}`}
                        >
                          <CardContent className="p-3">
                            <div className="flex items-center justify-between gap-4">
                              <div className="flex items-center space-x-2">
                                <div className="text-2xl">{upgrade.icon}</div>
                                <div>
                                  <TooltipProvider>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <h3 className="font-medium">
                                          {upgrade.name}{" "}
                                          {upgrade.level > 0 && (
                                            <span className="text-sm">
                                              Lv.{upgrade.level}
                                            </span>
                                          )}
                                        </h3>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                        <p className="max-w-xs">
                                          {upgrade.description}
                                        </p>
                                        {upgrade.clickPowerBonus > 0 && (
                                          <p className="text-green-500">
                                            +{upgrade.clickPowerBonus} click
                                            power per level
                                          </p>
                                        )}
                                        {upgrade.autoClickBonus > 0 && (
                                          <p className="text-blue-500">
                                            +{upgrade.autoClickBonus} auto
                                            clicks per level
                                          </p>
                                        )}
                                        {upgrade.comboBonus > 0 && (
                                          <p className="text-purple-500">
                                            +
                                            {(upgrade.comboBonus * 100).toFixed(
                                              0,
                                            )}
                                            % combo bonus
                                          </p>
                                        )}
                                      </TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>
                                  <div className="text-xs text-gray-600 dark:text-gray-400">
                                    Level: {upgrade.level}
                                  </div>
                                </div>
                              </div>

                              <div>
                                <Button
                                  onClick={() => handleBuyUpgrade(upgrade.id)}
                                  disabled={!canAfford}
                                  variant={canAfford ? "default" : "outline"}
                                  size="sm"
                                  className={
                                    canAfford
                                      ? "bg-amber-500 hover:bg-amber-600"
                                      : ""
                                  }
                                >
                                  {formatNumber(cost)} clicks
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            <TabsContent value="personalities" className="mt-4">
              <div className="space-y-3">
                {personalityTraits.map((trait) => {
                  const personalityName = trait.name;
                  const cost =
                    PERSONALITY_PRICES[
                      personalityName as keyof typeof PERSONALITY_PRICES
                    ] || 1000;
                  const isUnlocked =
                    unlockedPersonalities.includes(personalityName);
                  const canAfford = score >= cost;

                  return (
                    <motion.div
                      key={personalityName}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ type: "spring", damping: 20 }}
                      whileHover={{ scale: 1.02 }}
                    >
                      <Card
                        className={`relative overflow-hidden ${
                          isUnlocked
                            ? "bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/10"
                            : canAfford
                              ? "bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-900/20 dark:to-yellow-900/10"
                              : "bg-gray-50 dark:bg-gray-900"
                        }`}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center justify-between gap-4">
                            <div className="flex items-center space-x-2">
                              <div className="text-2xl">{trait.emoji}</div>
                              <div>
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <h3 className="font-medium">
                                        {personalityName} Personality
                                      </h3>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p className="max-w-xs">
                                        {trait.description}
                                      </p>
                                      {getPersonalityBonus(personalityName) >
                                        1 && (
                                        <p className="text-green-500">
                                          +
                                          {Math.round(
                                            (getPersonalityBonus(
                                              personalityName,
                                            ) -
                                              1) *
                                              100,
                                          )}
                                          % click power
                                        </p>
                                      )}
                                      {getPersonalityBonus(personalityName) <
                                        1 && (
                                        <p className="text-red-500">
                                          {Math.round(
                                            (getPersonalityBonus(
                                              personalityName,
                                            ) -
                                              1) *
                                              100,
                                          )}
                                          % click power
                                        </p>
                                      )}
                                      {getPersonalityAutoClickBonus(
                                        personalityName,
                                      ) > 0 && (
                                        <p className="text-blue-500">
                                          +
                                          {getPersonalityAutoClickBonus(
                                            personalityName,
                                          )}{" "}
                                          auto clicks/sec
                                        </p>
                                      )}
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                                <div className="text-xs text-gray-600 dark:text-gray-400">
                                  {trait.catchphrase &&
                                  trait.catchphrase.length > 0
                                    ? trait.catchphrase[0]
                                    : "So personality! Much trait!"}
                                </div>
                              </div>
                            </div>

                            <div>
                              {isUnlocked ? (
                                <Badge
                                  variant="outline"
                                  className="bg-green-500 text-white px-2 py-1"
                                >
                                  Unlocked
                                </Badge>
                              ) : (
                                <Button
                                  onClick={() =>
                                    handleBuyPersonality(personalityName, cost)
                                  }
                                  disabled={!canAfford}
                                  variant={canAfford ? "default" : "outline"}
                                  size="sm"
                                  className={
                                    canAfford
                                      ? "bg-amber-500 hover:bg-amber-600"
                                      : ""
                                  }
                                >
                                  <ShoppingCart className="h-4 w-4 mr-1" />
                                  {formatNumber(cost)}
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}

                {/* Display the secret GOD DOGE personality only when unlocked */}
                {godDogeUnlocked && (
                  <motion.div
                    key={secretPersonalityTrait.name}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ type: "spring", damping: 20 }}
                    whileHover={{ scale: 1.02 }}
                  >
                    <Card
                      className={`relative overflow-hidden ${
                        unlockedPersonalities.includes(
                          secretPersonalityTrait.name,
                        )
                          ? "bg-gradient-to-r from-purple-50 to-fuchsia-50 dark:from-purple-900/20 dark:to-fuchsia-900/10"
                          : score >= PERSONALITY_PRICES["GOD DOGE"]
                            ? "bg-gradient-to-r from-fuchsia-50 to-amber-50 dark:from-fuchsia-900/20 dark:to-amber-900/10 border-2 border-yellow-400"
                            : "bg-gradient-to-r from-gray-50 to-slate-50 dark:from-gray-900/50 dark:to-slate-900/50"
                      }`}
                    >
                      <div className="absolute top-0 right-0 bg-amber-400 text-white text-xs font-bold px-2 py-1 rounded-bl">
                        SECRET!
                      </div>
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center space-x-2">
                            <div className="text-2xl">
                              {secretPersonalityTrait.emoji}
                            </div>
                            <div>
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <h3 className="font-medium">
                                      {secretPersonalityTrait.name} Personality
                                    </h3>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p className="max-w-xs">
                                      {secretPersonalityTrait.description}
                                    </p>
                                    <p className="text-green-500">
                                      +
                                      {Math.round(
                                        (getPersonalityBonus(
                                          secretPersonalityTrait.name,
                                        ) -
                                          1) *
                                          100,
                                      )}
                                      % click power
                                    </p>
                                    <p className="text-blue-500">
                                      +
                                      {getPersonalityAutoClickBonus(
                                        secretPersonalityTrait.name,
                                      )}{" "}
                                      auto clicks/sec
                                    </p>
                                    <p className="text-amber-500 font-bold">
                                      CHEAT MODE!
                                    </p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                              <div className="text-xs text-amber-600 dark:text-amber-400 font-bold">
                                {secretPersonalityTrait.catchphrase &&
                                secretPersonalityTrait.catchphrase.length > 0
                                  ? secretPersonalityTrait.catchphrase[0]
                                  : "MUCH POWER! VERY CHEAT!"}
                              </div>
                            </div>
                          </div>

                          <div>
                            {unlockedPersonalities.includes(
                              secretPersonalityTrait.name,
                            ) ? (
                              <Badge
                                variant="outline"
                                className="bg-purple-500 text-white px-2 py-1"
                              >
                                ACTIVATED
                              </Badge>
                            ) : (
                              <Button
                                onClick={() =>
                                  handleBuyPersonality(
                                    secretPersonalityTrait.name,
                                    PERSONALITY_PRICES["GOD DOGE"],
                                  )
                                }
                                disabled={
                                  score < PERSONALITY_PRICES["GOD DOGE"]
                                }
                                variant={
                                  score >= PERSONALITY_PRICES["GOD DOGE"]
                                    ? "default"
                                    : "outline"
                                }
                                size="sm"
                                className={
                                  score >= PERSONALITY_PRICES["GOD DOGE"]
                                    ? "bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white font-bold"
                                    : ""
                                }
                              >
                                <ShoppingCart className="h-4 w-4 mr-1" />
                                {formatNumber(PERSONALITY_PRICES["GOD DOGE"])}
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>

        <CardFooter className="pb-4 pt-0 px-4">
          <div className="w-full text-center text-sm text-gray-500">
            You have {formatNumber(score)} clicks to spend
          </div>
        </CardFooter>
      </Card>
    </>
  );
};

export default UpgradeShop;
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useGame } from "@/lib/GameContext";
import { saveGameState, loadGameState } from "@/lib/GameContext";

export default function SaveLoadPanel() {
  const { state, dispatch } = useGame();
  const { toast } = useToast();
  const [sessionId, setSessionId] = useState<string>("");
  const [showLoadInput, setShowLoadInput] = useState<boolean>(false);

  // Get current session ID from localStorage
  const currentSessionId = localStorage.getItem("dogeSessionId");

  const handleSave = async () => {
    try {
      const id = await saveGameState(state);

      toast({
        title: "Game Saved",
        description: `Your game has been saved! Session ID: ${id}`,
      });

      // Copy session ID to clipboard
      navigator.clipboard
        .writeText(id)
        .then(() => {
          toast({
            title: "Session ID Copied",
            description: "Session ID has been copied to your clipboard",
            variant: "default",
          });
        })
        .catch((err) => {
          console.error("Could not copy session ID: ", err);
        });
    } catch (error) {
      console.error("Error saving game:", error);
      toast({
        title: "Save Failed",
        description: "Could not save your game data",
        variant: "destructive",
      });
    }
  };

  const handleLoad = async () => {
    if (!sessionId.trim()) {
      toast({
        title: "Invalid ID",
        description: "Please enter a valid session ID",
        variant: "destructive",
      });
      return;
    }

    try {
      const loadedState = await loadGameState(sessionId);

      if (!loadedState) {
        toast({
          title: "Game Not Found",
          description: "Could not find a saved game with that ID",
          variant: "destructive",
        });
        return;
      }

      dispatch({ type: "SET_GAME_STATE", state: loadedState });

      toast({
        title: "Game Loaded",
        description: `Your game has been loaded successfully!`,
      });

      setShowLoadInput(false);
    } catch (error) {
      console.error("Error loading game:", error);
      toast({
        title: "Load Failed",
        description: "Could not load your game data",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="w-full bg-[#F0E8DC] border-[#DDD6CA]">
      <CardHeader>
        <CardTitle className="text-[#5D534A]">Save & Load</CardTitle>
        <CardDescription className="text-[#8A7E6B]">
          Never lose your progress!
        </CardDescription>
      </CardHeader>
      <CardContent>
        {currentSessionId && (
          <div className="mb-4">
            <p className="text-xs text-muted-foreground mb-1">
              Current Session ID:
            </p>
            <div className="flex items-center gap-2">
              <code className="bg-muted p-1 rounded text-xs font-mono flex-1 overflow-hidden text-ellipsis">
                {currentSessionId}
              </code>
            </div>
          </div>
        )}

        {showLoadInput ? (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="sessionId">Enter your Session ID</Label>
              <Input
                id="sessionId"
                value={sessionId}
                onChange={(e) => setSessionId(e.target.value)}
                placeholder="Paste your session ID"
                className="font-mono"
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleLoad}
                size="sm"
                variant="default"
                className="w-full"
              >
                Load Game
              </Button>
              <Button
                onClick={() => setShowLoadInput(false)}
                size="sm"
                variant="outline"
                className="w-full"
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex gap-2">
            <Button
              onClick={handleSave}
              size="sm"
              variant="default"
              className="w-full"
            >
              Save Game
            </Button>
            <Button
              onClick={() => setShowLoadInput(true)}
              size="sm"
              variant="outline"
              className="w-full"
            >
              Load Game
            </Button>
          </div>
        )}
      </CardContent>
      <CardFooter className="px-6 py-3 border-t">
        <p className="text-xs text-muted-foreground w-full text-center">
          Your game is auto-saved every minute
        </p>
      </CardFooter>
    </Card>
  );
}
import React, { useState, useEffect } from "react";
import { useGame } from "../lib/GameContext";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "./ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "./ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./ui/tooltip";
import {
  Trophy,
  Award,
  Star,
  Zap,
  Target,
  Heart,
  Sparkles,
  Check,
  ChevronRight,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import AchievementCollection from "./AchievementCollection";
import AchievementConfetti from "./AchievementConfetti";

// Animation for badge shine effect
const shineAnimation = {
  initial: {
    background:
      "linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 100%)",
  },
  animate: {
    background: [
      "linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 100%)",
      "linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.8) 50%, rgba(255,255,255,0) 100%)",
      "linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 100%)",
    ],
    transition: {
      duration: 1.5,
      repeat: Infinity,
      repeatDelay: 3,
    },
  },
};

// Define badge colors based on rarity
const badgeColors = {
  common: {
    bg: "bg-gradient-to-r from-gray-200 to-gray-300",
    border: "border-gray-400",
    text: "text-gray-800",
    glow: "shadow-gray-400/50",
  },
  uncommon: {
    bg: "bg-gradient-to-r from-green-200 to-green-300",
    border: "border-green-400",
    text: "text-green-800",
    glow: "shadow-green-400/50",
  },
  rare: {
    bg: "bg-gradient-to-r from-blue-200 to-blue-300",
    border: "border-blue-400",
    text: "text-blue-800",
    glow: "shadow-blue-400/50",
  },
  epic: {
    bg: "bg-gradient-to-r from-purple-200 to-purple-300",
    border: "border-purple-400",
    text: "text-purple-800",
    glow: "shadow-purple-400/50",
  },
  legendary: {
    bg: "bg-gradient-to-r from-amber-200 to-amber-300",
    border: "border-amber-400",
    text: "text-amber-800",
    glow: "shadow-amber-400/50",
  },
};

// Get badge icon component based on type
const getBadgeIcon = (type: string) => {
  switch (type) {
    case "clicks":
      return <Zap className="h-5 w-5" />;
    case "combo":
      return <Sparkles className="h-5 w-5" />;
    case "personalities":
      return <Heart className="h-5 w-5" />;
    case "upgrades":
      return <Target className="h-5 w-5" />;
    case "score":
    default:
      return <Trophy className="h-5 w-5" />;
  }
};

// Get badge rarity based on requirement value
const getBadgeRarity = (achievement: any) => {
  const value = achievement.requirement.value;

  if (value >= 10000) return "legendary";
  if (value >= 1000) return "epic";
  if (value >= 500) return "rare";
  if (value >= 100) return "uncommon";
  return "common";
};

const AchievementBadge = ({
  achievement,
  onClick,
}: {
  achievement: any;
  onClick: () => void;
}) => {
  const { state } = useGame();
  const rarity = getBadgeRarity(achievement);
  const colors = badgeColors[rarity as keyof typeof badgeColors];
  const icon = getBadgeIcon(achievement.requirement.type);
  const personality = state.currentPersonality;

  // Generate personality-specific badge animations
  const getBadgeAnimation = () => {
    // Default animation
    let animation = {
      rotate: achievement.unlocked ? [0, 2, 0, -2, 0] : 0,
      scale: achievement.unlocked ? [1, 1.03, 1] : 1,
      boxShadow: achievement.unlocked
        ? [
            "0 0 0 rgba(0,0,0,0)",
            "0 0 15px rgba(255,255,0,0.5)",
            "0 0 0 rgba(0,0,0,0)",
          ]
        : "0 0 0 rgba(0,0,0,0)",
    };

    // Personalize based on personality
    if (achievement.unlocked && personality) {
      switch (personality) {
        case "Hyper":
          animation = {
            rotate: [0, 5, -5, 3, -3, 0],
            scale: [1, 1.1, 0.98, 1.05, 1],
            boxShadow: [
              "0 0 0 rgba(0,0,0,0)",
              "0 0 20px rgba(255,0,0,0.6)",
              "0 0 0 rgba(0,0,0,0)",
            ],
          };
          break;
        case "Party":
          animation = {
            rotate: [0, 8, -8, 4, -4, 0],
            scale: [1, 1.08, 1, 1.08, 1],
            boxShadow: [
              "0 0 0 rgba(0,0,0,0)",
              "0 0 20px rgba(0,255,255,0.6)",
              "0 0 0 rgba(0,0,0,0)",
            ],
          };
          break;
        case "Curious":
          animation = {
            rotate: [0, 3, 0, -3, 0],
            scale: [1, 1.05, 1, 1.05, 1],
            boxShadow: [
              "0 0 0 rgba(0,0,0,0)",
              "0 0 15px rgba(0,150,255,0.5)",
              "0 0 0 rgba(0,0,0,0)",
            ],
          };
          break;
        case "Silly":
          animation = {
            rotate: [0, 10, -5, 7, -10, 0],
            scale: [1, 1.1, 0.95, 1.05, 0.98, 1],
            boxShadow: [
              "0 0 0 rgba(0,0,0,0)",
              "0 0 15px rgba(255,100,0,0.5)",
              "0 0 0 rgba(0,0,0,0)",
            ],
          };
          break;
        case "Wise":
          animation = {
            rotate: [0, 1, 0, -1, 0],
            scale: [1, 1.02, 1, 1.02, 1],
            boxShadow: [
              "0 0 0 rgba(0,0,0,0)",
              "0 0 15px rgba(100,50,200,0.4)",
              "0 0 0 rgba(0,0,0,0)",
            ],
          };
          break;
        case "Chill":
          animation = {
            rotate: [0, 1, 0, -1, 0],
            scale: [1, 1.02, 1],
            boxShadow: [
              "0 0 0 rgba(0,0,0,0)",
              "0 0 10px rgba(0,200,150,0.3)",
              "0 0 0 rgba(0,0,0,0)",
            ],
          };
          break;
        case "Sleepy":
          animation = {
            rotate: [0, 1, 0, -1, 0],
            scale: [1, 1.01, 1],
            boxShadow: [
              "0 0 0 rgba(0,0,0,0)",
              "0 0 8px rgba(100,100,255,0.2)",
              "0 0 0 rgba(0,0,0,0)",
            ],
          };
          break;
      }
    }

    // Enhance for rare+ achievements
    if (achievement.unlocked) {
      if (rarity === "rare" && Array.isArray(animation.scale)) {
        animation.scale = animation.scale.map((s: number) => s * 1.05);
      } else if (rarity === "epic" && Array.isArray(animation.scale)) {
        animation.scale = animation.scale.map((s: number) => s * 1.08);
      } else if (rarity === "legendary" && Array.isArray(animation.scale)) {
        animation.scale = animation.scale.map((s: number) => s * 1.1);
      }
    }

    return animation;
  };

  const badgeAnimation = getBadgeAnimation();

  // Set animation transition properties
  const getAnimationTransition = () => {
    let duration = 2;
    let repeat = Infinity;
    let repeatDelay = 1;

    if (personality === "Hyper") {
      duration = 1.2;
      repeatDelay = 0.5;
    } else if (personality === "Sleepy") {
      duration = 3;
      repeatDelay = 2;
    }

    if (rarity === "legendary") {
      duration *= 0.8;
      repeatDelay *= 0.8;
    }

    return {
      duration,
      repeat: achievement.unlocked ? repeat : 0,
      repeatDelay,
    };
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <motion.div
            className={`relative cursor-pointer rounded-full p-4 border-2 ${colors.border} ${colors.bg} 
                         shadow-lg hover:shadow-xl transition-all transform hover:scale-105 ${achievement.unlocked ? colors.glow : "opacity-50 grayscale"}`}
            animate={
              achievement.unlocked
                ? {
                    rotate: badgeAnimation.rotate,
                    scale: badgeAnimation.scale,
                    boxShadow: badgeAnimation.boxShadow,
                  }
                : {}
            }
            transition={getAnimationTransition()}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={onClick}
            layout
          >
            {achievement.unlocked &&
              (rarity === "epic" || rarity === "legendary") && (
                <motion.div
                  className={`absolute inset-0 rounded-full overflow-hidden z-0 ${
                    rarity === "legendary" ? "bg-amber-50" : "bg-purple-50"
                  }`}
                  animate={{
                    opacity: [0.1, 0.3, 0.1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    repeatType: "reverse",
                  }}
                />
              )}

            {achievement.unlocked && (
              <motion.div
                className="absolute inset-0 rounded-full overflow-hidden z-0"
                {...shineAnimation}
              />
            )}

            <div className="relative z-10 flex items-center justify-center">
              <div className={`${colors.text}`}>
                {achievement.icon ? (
                  <span
                    className={`text-2xl ${
                      achievement.unlocked && rarity === "legendary"
                        ? "animate-pulse"
                        : ""
                    }`}
                  >
                    {achievement.icon}
                  </span>
                ) : (
                  icon
                )}
              </div>
            </div>

            {!achievement.unlocked && (
              <div className="absolute inset-0 flex items-center justify-center rounded-full">
                <span className="text-xl">🔒</span>
              </div>
            )}
          </motion.div>
        </TooltipTrigger>
        <TooltipContent>
          <p className="font-bold">{achievement.name}</p>
          <p className="text-xs opacity-75">
            {rarity.charAt(0).toUpperCase() + rarity.slice(1)}
          </p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

const AchievementDetails = ({
  achievement,
  onClose,
  isOpen,
}: {
  achievement: any;
  onClose: () => void;
  isOpen: boolean;
}) => {
  // For progress calculation
  const { state } = useGame();
  const [progress, setProgress] = useState(0);
  const [showDetailConfetti, setShowDetailConfetti] = useState(false);
  const personality = state.currentPersonality;

  // Show confetti for milestone achievements
  useEffect(() => {
    if (achievement && isOpen) {
      // Milestone achievements defined in AchievementConfetti component
      const milestoneIds = [
        "clicks_1000",
        "clicks_10000",
        "clicks_100000",
        "clicks_1000000",
        "score_10000",
        "score_100000",
        "score_1000000",
        "combo_50",
        "combo_100",
        "personalities_7",
        "upgrades_all",
      ];

      if (milestoneIds.includes(achievement.id)) {
        setShowDetailConfetti(true);

        // Clear confetti after 4 seconds
        const timer = setTimeout(() => {
          setShowDetailConfetti(false);
        }, 4000);

        return () => clearTimeout(timer);
      }
    }
  }, [achievement, isOpen]);

  // Always define these variables (even if achievement is null)
  const rarity = achievement ? getBadgeRarity(achievement) : "common";
  const colors = badgeColors[rarity as keyof typeof badgeColors];
  const icon =
    achievement && achievement.requirement ? (
      getBadgeIcon(achievement.requirement.type)
    ) : (
      <Trophy className="h-5 w-5" />
    );

  // Get personality-specific animation styles
  const getPersonalityAnimationStyle = () => {
    // Default animation
    let animationStyle = {
      rotate: [0, 5, 0, -5, 0],
      scale: [1, 1.05, 1],
      duration: 1.5,
      repeat: achievement?.unlocked ? Infinity : 0,
      repeatDelay: 2,
    };

    // Adjust based on personality
    if (personality) {
      switch (personality) {
        case "Hyper":
          animationStyle = {
            rotate: [0, 10, -10, 15, -15, 0],
            scale: [1, 1.2, 0.9, 1.1, 1],
            duration: 0.8,
            repeat: achievement?.unlocked ? Infinity : 0,
            repeatDelay: 0.5,
          };
          break;
        case "Party":
          animationStyle = {
            rotate: [0, 15, -15, 10, -10, 5, -5, 0],
            scale: [1, 1.1, 1, 1.15, 1],
            duration: 2,
            repeat: achievement?.unlocked ? Infinity : 0,
            repeatDelay: 0.8,
          };
          break;
        case "Curious":
          animationStyle = {
            rotate: [0, 7, 0, -7, 0],
            scale: [1, 1.1, 1, 1.1, 1],
            duration: 1.2,
            repeat: achievement?.unlocked ? Infinity : 0,
            repeatDelay: 0.7,
          };
          break;
        case "Silly":
          animationStyle = {
            rotate: [0, 20, -15, 10, -20, 15, 0],
            scale: [1, 0.9, 1.2, 0.8, 1.1, 0.9, 1],
            duration: 1.8,
            repeat: achievement?.unlocked ? Infinity : 0,
            repeatDelay: 1,
          };
          break;
        case "Wise":
          animationStyle = {
            rotate: [0, 3, 0, -3, 0],
            scale: [1, 1.03, 1, 1.03, 1],
            duration: 2.5,
            repeat: achievement?.unlocked ? Infinity : 0,
            repeatDelay: 1.5,
          };
          break;
        case "Chill":
          animationStyle = {
            rotate: [0, 2, 0, -2, 0],
            scale: [1, 1.02, 1, 1.02, 1],
            duration: 3,
            repeat: achievement?.unlocked ? Infinity : 0,
            repeatDelay: 2,
          };
          break;
        case "Sleepy":
          animationStyle = {
            rotate: [0, 1, 0, -1, 0],
            scale: [1, 1.01, 1, 1.01, 1],
            duration: 4,
            repeat: achievement?.unlocked ? Infinity : 0,
            repeatDelay: 3,
          };
          break;
      }
    }

    // Enhance for rare+ achievements
    if (rarity === "rare" || rarity === "epic" || rarity === "legendary") {
      if (Array.isArray(animationStyle.scale)) {
        animationStyle.scale = animationStyle.scale.map((s: number) => s * 1.1);
      }
      animationStyle.duration = Math.max(0.8, animationStyle.duration * 0.8);
    }

    return animationStyle;
  };

  // Calculate progress based on achievement type
  useEffect(() => {
    if (!achievement || !achievement.requirement) return;

    const req = achievement.requirement;
    let currentValue = 0;

    switch (req.type) {
      case "score":
        currentValue = state.score;
        break;
      case "combo":
        currentValue = state.highestCombo;
        break;
      case "upgrades":
        currentValue = state.upgrades.filter((u) => u.purchased).length;
        break;
      case "personalities":
        // This would need additional tracking in state
        currentValue = 0;
        break;
    }

    const calculatedProgress = Math.min(100, (currentValue / req.value) * 100);
    setProgress(calculatedProgress);
  }, [achievement, state]);

  // Return null after hooks
  if (!achievement) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <DialogContent className="sm:max-w-md bg-[#F0E8DC] border-[#DDD6CA] text-[#5D534A]">
          {/* Show confetti for milestone achievements */}
          {showDetailConfetti && (
            <div className="absolute inset-0 pointer-events-none">
              <AchievementConfetti achievement={achievement} duration={4000} />
            </div>
          )}

          <DialogHeader>
            <DialogTitle>Achievement Details</DialogTitle>
            <DialogDescription>
              Unlock achievements to earn special bonuses
            </DialogDescription>
          </DialogHeader>

          <div className="flex flex-col items-center py-4">
            {/* Celebration background effects for legendary/epic achievements */}
            {achievement.unlocked &&
              (rarity === "legendary" || rarity === "epic") && (
                <motion.div
                  className="absolute inset-0 -m-8 z-0 rounded-full overflow-hidden"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.7 }}
                >
                  {Array.from({ length: 12 }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute h-3 w-3 rounded-full"
                      style={{
                        backgroundColor:
                          rarity === "legendary" ? "#FFD700" : "#BA55D3",
                        top: "50%",
                        left: "50%",
                        translateX: "-50%",
                        translateY: -50 - 100 + "%",
                        rotate: i * 30 + "deg",
                      }}
                      animate={{
                        opacity: [0.7, 0.3, 0.7],
                        scale: [1, 1.2, 1],
                        rotate: [i * 30, i * 30 + 360],
                      }}
                      transition={{
                        duration: rarity === "legendary" ? 4 : 6,
                        repeat: Infinity,
                        ease: "linear",
                        delay: i * 0.2,
                      }}
                    />
                  ))}
                </motion.div>
              )}

            {/* Achievement icon with personalized animations */}
            <motion.div
              className={`relative cursor-pointer rounded-full p-6 border-4 ${colors.border} ${colors.bg} 
                       shadow-2xl ${achievement.unlocked ? colors.glow : "opacity-70 grayscale"} z-10`}
              animate={
                achievement.unlocked
                  ? {
                      rotate: getPersonalityAnimationStyle().rotate,
                      scale: getPersonalityAnimationStyle().scale,
                    }
                  : { rotate: 0, scale: 1 }
              }
              transition={{
                duration: getPersonalityAnimationStyle().duration,
                repeat: getPersonalityAnimationStyle().repeat,
                repeatDelay: getPersonalityAnimationStyle().repeatDelay,
              }}
            >
              <div className="relative z-10 flex items-center justify-center text-3xl">
                {achievement.icon ? <span>{achievement.icon}</span> : icon}
              </div>
              {!achievement.unlocked && (
                <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 rounded-full">
                  <span className="text-3xl">🔒</span>
                </div>
              )}
            </motion.div>

            <div className="mt-4 text-center">
              <h2 className="text-xl font-bold">{achievement.name}</h2>
              <Badge
                variant="outline"
                className={`mt-1 ${colors.bg} ${colors.text}`}
              >
                {rarity.charAt(0).toUpperCase() + rarity.slice(1)}
              </Badge>

              <p className="mt-4">{achievement.description}</p>

              {!achievement.unlocked && (
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Progress</span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              )}

              {achievement.unlocked && achievement.reward && (
                <div className="mt-4">
                  <div className="py-2 px-4 bg-green-100 text-green-800 rounded-md mb-2">
                    <span>🏆 Achieved!</span>
                  </div>

                  {achievement.reward.type !== "none" && (
                    <div className="mt-2 py-2 px-4 bg-blue-50 text-blue-800 rounded-md">
                      <h3 className="font-bold text-sm">Reward Earned:</h3>
                      <p className="text-sm">
                        {achievement.reward.type === "clickPower" && (
                          <>+{achievement.reward.value} Click Power</>
                        )}
                        {achievement.reward.type === "autoClick" && (
                          <>
                            +{achievement.reward.value} Auto-clicks per second
                          </>
                        )}
                        {achievement.reward.type === "comboTime" && (
                          <>+{achievement.reward.value}ms Combo Window</>
                        )}
                        {achievement.reward.type === "comboMultiplier" && (
                          <>×{achievement.reward.value} Combo Multiplier</>
                        )}
                        {achievement.reward.type === "clickMultiplier" && (
                          <>×{achievement.reward.value} Click Multiplier</>
                        )}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button onClick={onClose}>Close</Button>
          </DialogFooter>
        </DialogContent>
      )}
    </AnimatePresence>
  );
};

// Achievement toast notification component with personalized animations
const AchievementToast = ({ achievement }: { achievement: any }) => {
  const { state } = useGame();
  const rarity = getBadgeRarity(achievement);
  const colors = badgeColors[rarity as keyof typeof badgeColors];
  const personality = state.currentPersonality;

  // Define animation variants based on personality and achievement rarity
  const getAnimationVariants = () => {
    let scale = [1, 1.2, 1];
    let rotate = [0, 0, 0];
    let y = [0, -5, 0];
    let transition = {
      duration: 0.5,
      repeat: 2,
      repeatType: "reverse" as const,
    };

    // Enhance animation based on rarity
    if (rarity === "rare" || rarity === "epic") {
      scale = [1, 1.3, 1];
      transition.duration = 0.7;
      transition.repeat = 3;
    }

    if (rarity === "legendary") {
      scale = [1, 1.4, 1];
      rotate = [0, 10, -10, 0];
      transition.duration = 1;
      transition.repeat = 4;
    }

    // Modify animation based on personality
    if (personality === "Hyper") {
      scale = [1, 1.5, 0.9, 1.3, 1];
      rotate = [0, 15, -15, 10, -10, 0];
      transition.duration = 0.3;
      transition.repeat = 5;
    }

    if (personality === "Party") {
      rotate = [0, 20, -20, 15, -15, 0];
      y = [0, -10, 5, -5, 0];
    }

    if (personality === "Sleepy") {
      scale = [1, 1.1, 1];
      rotate = [0, 3, -3, 0];
      transition.duration = 1.5;
      transition.repeat = 1;
    }

    return {
      initial: { scale: 1, rotate: 0, y: 0 },
      animate: {
        scale,
        rotate,
        y,
        transition,
      },
    };
  };

  // Get celebration text based on personality
  const getCelebrationText = () => {
    const defaultText = "Achievement Unlocked";

    if (!personality) return defaultText;

    switch (personality) {
      case "Hyper":
        return "WOW!! AMAZING ACHIEVEMENT!!";
      case "Party":
        return "Achievement Party Time!";
      case "Curious":
        return "Ooh, What's This Achievement?";
      case "Silly":
        return "Much Achievement, Very Wow!";
      case "Wise":
        return "Achievement of Great Wisdom";
      case "Chill":
        return "Cool Achievement, Bro";
      case "Sleepy":
        return "zzz...Achievement...zzz";
      default:
        return defaultText;
    }
  };

  const animationVariants = getAnimationVariants();
  const celebrationText = getCelebrationText();

  // Define confetti colors based on rarity
  const confettiColors = {
    common: ["#A0A0A0", "#C0C0C0", "#D0D0D0"],
    uncommon: ["#90EE90", "#98FB98", "#ADFF2F"],
    rare: ["#87CEFA", "#00BFFF", "#1E90FF"],
    epic: ["#DA70D6", "#BA55D3", "#9370DB"],
    legendary: ["#FFD700", "#FFA500", "#FF8C00"],
  };

  return (
    <motion.div
      className="flex items-center space-x-3 relative"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Confetti animation for rare+ achievements */}
      {(rarity === "rare" || rarity === "epic" || rarity === "legendary") && (
        <motion.div
          className="absolute -inset-4 z-0 overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute h-2 w-2 rounded-full"
              style={{
                backgroundColor:
                  confettiColors[rarity as keyof typeof confettiColors][i % 3],
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
              }}
              initial={{
                y: -20,
                x: 0,
                opacity: 1,
              }}
              animate={{
                y: 100,
                x: (Math.random() - 0.5) * 80,
                opacity: 0,
                rotate: Math.random() * 360,
              }}
              transition={{
                duration: 1 + Math.random() * 1.5,
                delay: Math.random() * 0.5,
                ease: "easeOut",
              }}
            />
          ))}
        </motion.div>
      )}

      <motion.div
        className={`p-3 rounded-full ${colors.bg} ${colors.border} ${colors.glow} relative z-10`}
        {...animationVariants}
      >
        {achievement.icon ? (
          <span
            className={`text-xl ${rarity === "legendary" ? "animate-pulse" : ""}`}
          >
            {achievement.icon}
          </span>
        ) : (
          getBadgeIcon(achievement.requirement.type)
        )}
      </motion.div>

      <div className="relative z-10">
        <motion.div
          className="font-bold flex items-center"
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <span>{celebrationText}</span>
          <Check className="h-4 w-4 ml-1 text-green-500" />
        </motion.div>

        <motion.div
          className="text-sm text-gray-700 font-medium"
          initial={{ x: -10, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          {achievement.name}
        </motion.div>

        {achievement.reward && achievement.reward.type !== "none" && (
          <motion.div
            className={`text-xs font-medium mt-1 ${
              rarity === "legendary"
                ? "text-amber-500"
                : rarity === "epic"
                  ? "text-purple-500"
                  : rarity === "rare"
                    ? "text-blue-500"
                    : "text-green-500"
            }`}
            initial={{ x: -5, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            +
            {achievement.reward.type === "clickPower"
              ? `${achievement.reward.value} Click Power`
              : achievement.reward.type === "autoClick"
                ? `${achievement.reward.value} Auto-clicks/s`
                : achievement.reward.type === "comboTime"
                  ? `${achievement.reward.value}ms Combo Time`
                  : achievement.reward.type === "comboMultiplier" ||
                      achievement.reward.type === "clickMultiplier"
                    ? `${achievement.reward.value}x Multiplier`
                    : "Reward"}
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

const Achievements: React.FC = () => {
  const { state } = useGame();
  const { achievements } = state;
  const { toast } = useToast();

  const [selectedAchievement, setSelectedAchievement] = useState<any>(null);
  const [showDialog, setShowDialog] = useState(false);
  const [showCollection, setShowCollection] = useState(false);
  const [newlyUnlocked, setNewlyUnlocked] = useState<string[]>([]);
  const [confettiAchievement, setConfettiAchievement] = useState<any>(null);

  // Check for newly unlocked achievements
  useEffect(() => {
    const unlocked = achievements.filter((a) => a.unlocked);

    // Check if we have new unlocks by comparing to our tracked unlocks
    unlocked.forEach((achievement) => {
      if (!newlyUnlocked.includes(achievement.id)) {
        // Add to newly unlocked list
        setNewlyUnlocked((prev) => [...prev, achievement.id]);

        // Only show popups if enabled in settings
        if (state.settings.showAchievementPopups) {
          // Show celebration animation for new achievement
          setSelectedAchievement(achievement);
          setShowDialog(true);

          // Trigger confetti for milestone achievements
          setConfettiAchievement(achievement);

          // Clear confetti after 6 seconds
          setTimeout(() => {
            setConfettiAchievement(null);
          }, 6000);

          // Show toast notification
          toast({
            title: "Achievement Unlocked!",
            description: <AchievementToast achievement={achievement} />,
            duration: 5000, // 5 seconds
          });
        }
      }
    });
  }, [achievements, toast, state.settings.showAchievementPopups]);

  const unlockedAchievements = achievements.filter((a) => a.unlocked);
  const lockedAchievements = achievements.filter((a) => !a.unlocked);

  const handleShowAchievement = (achievement: any) => {
    setSelectedAchievement(achievement);
    setShowDialog(true);
  };

  return (
    <>
      {/* Render confetti animation when milestone achievements are unlocked */}
      {confettiAchievement && (
        <AchievementConfetti achievement={confettiAchievement} />
      )}

      <Accordion type="single" collapsible className="w-full">
        <AccordionItem
          value="achievements"
          className="bg-[#F0E8DC] border-[#DDD6CA] rounded-md"
        >
          <AccordionTrigger className="py-2 text-[#5D534A]">
            <div className="flex items-center gap-2">
              <Award className="h-4 w-4" />
              <span>Achievements</span>
              <Badge variant="secondary" className="ml-2">
                {unlockedAchievements.length}/{achievements.length}
              </Badge>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <Card className="w-full border-none shadow-none bg-[#F0E8DC] border-[#DDD6CA]">
              <CardContent className="p-4">
                {/* Badge Grid */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  {achievements.slice(0, 6).map((achievement) => (
                    <AchievementBadge
                      key={achievement.id}
                      achievement={achievement}
                      onClick={() => handleShowAchievement(achievement)}
                    />
                  ))}
                </div>

                {unlockedAchievements.length === 0 ? (
                  <div className="text-center py-2 text-gray-500 text-sm">
                    Keep clicking to unlock achievements!
                  </div>
                ) : (
                  <div className="text-center text-sm text-gray-600 mb-2">
                    Click on badges to view details
                  </div>
                )}

                {/* View All Achievements Button */}
                <Button
                  variant="outline"
                  className="w-full mt-2 text-amber-600 border-amber-200 hover:bg-amber-50"
                  onClick={() => setShowCollection(true)}
                >
                  <div className="flex items-center justify-center w-full">
                    <Award className="h-4 w-4 mr-2" />
                    <span>View All Achievements</span>
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </div>
                </Button>
              </CardContent>
            </Card>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {/* Achievement Details Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <AchievementDetails
          achievement={selectedAchievement}
          onClose={() => setShowDialog(false)}
          isOpen={showDialog}
        />
      </Dialog>

      {/* Achievement Collection Dialog */}
      <Dialog open={showCollection} onOpenChange={setShowCollection}>
        <DialogContent className="sm:max-w-4xl h-[80vh] overflow-y-auto bg-[#F0E8DC] border-[#DDD6CA] text-[#5D534A]">
          <DialogHeader>
            <DialogTitle className="text-2xl">
              Achievement Collection
            </DialogTitle>
            <DialogDescription className="text-[#8A7E6B]">
              Track your progress and unlock special rewards
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <AchievementCollection />
          </div>

          <DialogFooter>
            <Button onClick={() => setShowCollection(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default Achievements;
import React, { useState, useEffect } from "react";
import Confetti from "react-confetti";
import { useWindowSize } from "react-use";
import { Achievement } from "@/lib/gameUtils";
import { useGame } from "@/lib/GameContext";

// Define milestone achievements that will show confetti
const MILESTONE_ACHIEVEMENTS = [
  "clicks_1000",
  "clicks_10000",
  "clicks_100000",
  "clicks_1000000",
  "score_10000",
  "score_100000",
  "score_1000000",
  "score_10000000",
  "combo_50",
  "combo_100",
  "personalities_7",
  "upgrades_all",
];

interface AchievementConfettiProps {
  achievement: Achievement;
  duration?: number; // Duration in milliseconds
}

const AchievementConfetti: React.FC<AchievementConfettiProps> = ({
  achievement,
  duration = 5000,
}) => {
  const [showConfetti, setShowConfetti] = useState(false);
  const { width, height } = useWindowSize();
  const { state } = useGame();

  // Personality-specific confetti colors
  const getConfettiColors = () => {
    const personality = state.currentPersonality;

    // Default confetti colors (gold, achievement color theme)
    let colors = ["#FFD700", "#FFC107", "#FFECB3", "#FFE082"];

    // Personality-specific colors
    if (personality) {
      switch (personality) {
        case "zen":
          return ["#D1E3DD", "#8FBCBB", "#88C0D0", "#81A1C1"];
        case "spooky":
          return ["#6e0b14", "#8a1a1a", "#4d1010", "#3f0808"];
        case "rainbow":
          return [
            "#FF5252",
            "#FF4081",
            "#E040FB",
            "#7C4DFF",
            "#536DFE",
            "#448AFF",
            "#40C4FF",
            "#18FFFF",
            "#64FFDA",
            "#69F0AE",
            "#B2FF59",
            "#EEFF41",
            "#FFFF00",
            "#FFD740",
            "#FFAB40",
            "#FF6E40",
          ];
        case "cool":
          return ["#304FFE", "#2979FF", "#00B0FF", "#00E5FF"];
        case "royal":
          return ["#AA00FF", "#7C4DFF", "#651FFF", "#6200EA", "#D500F9"];
        case "GOD DOGE":
          // Gold with bright accents for GOD DOGE
          return [
            "#FFD700",
            "#FFC107",
            "#FFAB00",
            "#FF8F00",
            "#FFC400",
            "#FFEA00",
          ];
        case "ninja":
          return ["#212121", "#424242", "#616161", "#757575"];
        default:
          return colors;
      }
    }

    return colors;
  };

  // Customize confetti based on achievement type
  const getConfettiProps = () => {
    const achievementType = achievement.requirement.type;

    // Base props
    const props: any = {
      colors: getConfettiColors(),
      recycle: false,
      numberOfPieces: 200,
      gravity: 0.25,
    };

    // Customize based on achievement type
    switch (achievementType) {
      case "score":
        props.numberOfPieces = 300;
        props.gravity = 0.2;
        break;
      case "combo":
        props.numberOfPieces = 250;
        props.gravity = 0.3;
        props.wind = 0.01;
        break;
      case "personalities":
        props.numberOfPieces = 350;
        props.gravity = 0.15;
        props.confettiSource = { x: width / 2, y: height / 2, w: 0, h: 0 };
        props.initialVelocityY = 20;
        break;
      case "upgrades":
        props.numberOfPieces = 400;
        props.gravity = 0.15;
        break;
      default:
        break;
    }

    return props;
  };

  useEffect(() => {
    // Only show confetti for milestone achievements
    if (achievement && MILESTONE_ACHIEVEMENTS.includes(achievement.id)) {
      setShowConfetti(true);

      // Cleanup
      const timer = setTimeout(() => {
        setShowConfetti(false);
      }, duration);

      return () => clearTimeout(timer);
    }
  }, [achievement, duration]);

  if (!showConfetti || !MILESTONE_ACHIEVEMENTS.includes(achievement.id)) {
    return null;
  }

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      <Confetti
        width={width}
        height={height}
        run={showConfetti}
        {...getConfettiProps()}
      />
    </div>
  );
};

export default AchievementConfetti;
import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { v4 as uuidv4 } from "uuid";
import { insertPlayerDataSchema, updatePlayerDataSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Player data routes - prefix all routes with /api

  // Get player data by session ID
  app.get(
    "/api/player-data/:sessionId",
    async (req: Request, res: Response) => {
      try {
        const { sessionId } = req.params;
        const playerData = await storage.getPlayerData(sessionId);

        if (!playerData) {
          return res.status(404).json({ error: "Player data not found" });
        }

        return res.json(playerData);
      } catch (error) {
        console.error("Error fetching player data:", error);
        return res.status(500).json({ error: "Failed to fetch player data" });
      }
    },
  );

  // Create new player data
  app.post("/api/player-data", async (req: Request, res: Response) => {
    try {
      // Generate a unique session ID
      const sessionId = req.body.sessionId || uuidv4();

      // Validate request data
      const validatedData = insertPlayerDataSchema.parse({
        ...req.body,
        sessionId,
      });

      // Create player data in database
      const playerData = await storage.createPlayerData(validatedData);

      return res.status(201).json(playerData);
    } catch (error) {
      console.error("Error creating player data:", error);

      if (error instanceof ZodError) {
        return res
          .status(400)
          .json({ error: "Invalid player data", details: error.errors });
      }

      return res.status(500).json({ error: "Failed to create player data" });
    }
  });

  // Update player data
  app.put(
    "/api/player-data/:sessionId",
    async (req: Request, res: Response) => {
      try {
        const { sessionId } = req.params;

        // Check if player data exists
        const existingData = await storage.getPlayerData(sessionId);
        if (!existingData) {
          return res.status(404).json({ error: "Player data not found" });
        }

        // Validate update data
        const validatedData = updatePlayerDataSchema.parse(req.body);

        // Update player data
        const updatedData = await storage.updatePlayerData(
          sessionId,
          validatedData,
        );

        return res.json(updatedData);
      } catch (error) {
        console.error("Error updating player data:", error);

        if (error instanceof ZodError) {
          return res
            .status(400)
            .json({ error: "Invalid player data", details: error.errors });
        }

        return res.status(500).json({ error: "Failed to update player data" });
      }
    },
  );

  // Delete player data
  app.delete(
    "/api/player-data/:sessionId",
    async (req: Request, res: Response) => {
      try {
        const { sessionId } = req.params;

        // Check if player data exists
        const existingData = await storage.getPlayerData(sessionId);
        if (!existingData) {
          return res.status(404).json({ error: "Player data not found" });
        }

        // Delete player data
        await storage.deletePlayerData(sessionId);

        return res.status(204).send();
      } catch (error) {
        console.error("Error deleting player data:", error);
        return res.status(500).json({ error: "Failed to delete player data" });
      }
    },
  );

  const httpServer = createServer(app);

  return httpServer;
}
import {
  users,
  playerData,
  type User,
  type InsertUser,
  type PlayerData,
  type InsertPlayerData,
  type UpdatePlayerData,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Storage interface with CRUD methods for users and player data
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Player data methods
  getPlayerData(sessionId: string): Promise<PlayerData | undefined>;
  createPlayerData(data: InsertPlayerData): Promise<PlayerData>;
  updatePlayerData(
    sessionId: string,
    data: UpdatePlayerData,
  ): Promise<PlayerData | undefined>;
  deletePlayerData(sessionId: string): Promise<void>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Player data methods
  async getPlayerData(sessionId: string): Promise<PlayerData | undefined> {
    const [data] = await db
      .select()
      .from(playerData)
      .where(eq(playerData.sessionId, sessionId));
    return data || undefined;
  }

  async createPlayerData(data: InsertPlayerData): Promise<PlayerData> {
    const [playerDataEntry] = await db
      .insert(playerData)
      .values(data)
      .returning();
    return playerDataEntry;
  }

  async updatePlayerData(
    sessionId: string,
    data: UpdatePlayerData,
  ): Promise<PlayerData | undefined> {
    // Using the lastUpdated field to track when the data was last updated
    const now = new Date();

    const [updatedData] = await db
      .update(playerData)
      .set({
        ...data,
        lastUpdated: now,
      })
      .where(eq(playerData.sessionId, sessionId))
      .returning();

    return updatedData || undefined;
  }

  async deletePlayerData(sessionId: string): Promise<void> {
    await db.delete(playerData).where(eq(playerData.sessionId, sessionId));
  }
}

export const storage = new DatabaseStorage();
import {
  pgTable,
  text,
  serial,
  integer,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const playerData = pgTable("player_data", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  sessionId: text("session_id").notNull().unique(),
  score: integer("score").notNull().default(0),
  clickPower: integer("click_power").notNull().default(1),
  autoClickRate: integer("auto_click_rate").notNull().default(0),
  personalityBonus: integer("personality_bonus").notNull().default(1),
  currentPersonality: text("current_personality"),
  unlockedPersonalities: text("unlocked_personalities").array(),
  upgrades: jsonb("upgrades").notNull(),
  achievements: jsonb("achievements").notNull(),
  comboTimeWindow: integer("combo_time_window").notNull().default(1000),
  highestCombo: integer("highest_combo").notNull().default(0),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
  showAchievementPopups: boolean("show_achievement_popups")
    .notNull()
    .default(true),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPlayerDataSchema = createInsertSchema(playerData).pick({
  sessionId: true,
  userId: true,
  score: true,
  clickPower: true,
  autoClickRate: true,
  personalityBonus: true,
  currentPersonality: true,
  unlockedPersonalities: true,
  upgrades: true,
  achievements: true,
  comboTimeWindow: true,
  highestCombo: true,
  showAchievementPopups: true,
});

export const updatePlayerDataSchema = createInsertSchema(playerData).pick({
  score: true,
  clickPower: true,
  autoClickRate: true,
  personalityBonus: true,
  currentPersonality: true,
  unlockedPersonalities: true,
  upgrades: true,
  achievements: true,
  comboTimeWindow: true,
  highestCombo: true,
  showAchievementPopups: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertPlayerData = z.infer<typeof insertPlayerDataSchema>;
export type UpdatePlayerData = z.infer<typeof updatePlayerDataSchema>;
export type PlayerData = typeof playerData.$inferSelect;
import { useState, useEffect, useCallback, useRef } from "react";
import { PHYSICS } from "@/lib/utils";

interface Segment {
  x: number;
  y: number;
  vx: number;
  vy: number;
  targetX: number;
  targetY: number;
  lastX: number;
  lastY: number;
  width: number;
  height: number;
  rotation: number;
}

interface ContainerSize {
  width: number;
  height: number;
}

export default function useWobble(containerSize: ContainerSize) {
  const [segments, setSegments] = useState<Segment[]>([]);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const autoWobbleIntervalRef = useRef<number | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Initialize doge segments
  const initDoge = useCallback(() => {
    if (containerSize.width === 0 || containerSize.height === 0) return;

    const centerX = containerSize.width / 2;
    const centerY = containerSize.height / 2;

    const newSegments: Segment[] = [];

    // Head (first segment)
    newSegments.push({
      x: centerX,
      y: centerY,
      vx: 0,
      vy: 0,
      targetX: centerX,
      targetY: centerY,
      lastX: centerX,
      lastY: centerY,
      width: PHYSICS.SEGMENT_WIDTH + 20,
      height: PHYSICS.SEGMENT_HEIGHT + 20,
      rotation: 0,
    });

    // Body segments
    for (let i = 1; i < PHYSICS.SEGMENTS; i++) {
      newSegments.push({
        x: newSegments[i - 1].x - PHYSICS.SEGMENT_WIDTH / 2,
        y: newSegments[i - 1].y,
        vx: 0,
        vy: 0,
        targetX: newSegments[i - 1].x - PHYSICS.SEGMENT_WIDTH / 2,
        targetY: newSegments[i - 1].y,
        lastX: newSegments[i - 1].x - PHYSICS.SEGMENT_WIDTH / 2,
        lastY: newSegments[i - 1].y,
        width: PHYSICS.SEGMENT_WIDTH - i * 1.5,
        height: PHYSICS.SEGMENT_HEIGHT - i * 0.5,
        rotation: 0,
      });
    }

    setSegments(newSegments);
  }, [containerSize]);

  // Mouse movement handler
  const handleMouseMove = useCallback((x: number, y: number) => {
    setMousePos({ x, y });
  }, []);

  // Trigger wobble effect
  const triggerWobble = useCallback(() => {
    setSegments((prevSegments) => {
      const newSegments = [...prevSegments];
      if (newSegments.length > 0) {
        // Apply stronger impulse for more dramatic effect
        newSegments[0] = {
          ...newSegments[0],
          vx: newSegments[0].vx + (Math.random() - 0.5) * 60,
          vy: newSegments[0].vy + (Math.random() - 0.5) * 60,
        };

        // Also add some smaller impulses to a few body segments
        // for a more interesting motion that propagates down the body
        for (let i = 1; i < Math.min(newSegments.length, 4); i++) {
          newSegments[i] = {
            ...newSegments[i],
            vx: newSegments[i].vx + (Math.random() - 0.5) * 30 * (1 - i / 4),
            vy: newSegments[i].vy + (Math.random() - 0.5) * 30 * (1 - i / 4),
          };
        }
      }
      return newSegments;
    });
  }, []);

  // Reset doge position
  const resetDoge = useCallback(() => {
    if (containerSize.width === 0 || containerSize.height === 0) return;

    const centerX = containerSize.width / 2;
    const centerY = containerSize.height / 2;

    setSegments((prevSegments) => {
      const newSegments = [...prevSegments];
      if (newSegments.length > 0) {
        newSegments[0] = {
          ...newSegments[0],
          targetX: centerX,
          targetY: centerY,
          vx: 0,
          vy: 0,
        };
      }
      return newSegments;
    });

    // Clear auto wobble
    if (autoWobbleIntervalRef.current) {
      window.clearInterval(autoWobbleIntervalRef.current);
      autoWobbleIntervalRef.current = null;
    }

    // Start auto wobble again
    startAutoWobble();
  }, [containerSize]);

  // Update physics for segments
  const updatePhysics = useCallback(() => {
    if (segments.length === 0) return;

    setSegments((prevSegments) => {
      const newSegments = [...prevSegments];

      // Update head segment (influenced by mouse)
      if (newSegments.length > 0) {
        const head = newSegments[0];

        // Apply mouse influence if nearby
        const dx = mousePos.x - head.x;
        const dy = mousePos.y - head.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < 100) {
          head.targetX += dx * PHYSICS.MOUSE_INFLUENCE;
          head.targetY += dy * PHYSICS.MOUSE_INFLUENCE;
        }

        // Apply spring physics
        const fx = (head.targetX - head.x) * PHYSICS.SPRING_STIFFNESS;
        const fy = (head.targetY - head.y) * PHYSICS.SPRING_STIFFNESS;

        head.vx = head.vx * PHYSICS.FRICTION + fx;
        head.vy = head.vy * PHYSICS.FRICTION + fy;

        // Apply damping
        head.vx -= head.vx * PHYSICS.SPRING_DAMPING;
        head.vy -= head.vy * PHYSICS.SPRING_DAMPING;

        // Update position
        head.x += head.vx;
        head.y += head.vy;

        // Constrain to container
        const padding = 10;
        head.x = Math.max(
          padding,
          Math.min(containerSize.width - head.width - padding, head.x),
        );
        head.y = Math.max(
          padding,
          Math.min(containerSize.height - head.height - padding, head.y),
        );

        // Store last position
        head.lastX = head.x;
        head.lastY = head.y;
      }

      // Update body segments
      for (let i = 1; i < newSegments.length; i++) {
        const prevSeg = newSegments[i - 1];
        const currentSeg = newSegments[i];

        // Calculate angle between segments
        const dx = prevSeg.x - currentSeg.x;
        const dy = prevSeg.y - currentSeg.y;
        const angle = Math.atan2(dy, dx);

        // Set target position maintaining distance from previous segment
        const targetDistance = (prevSeg.width + currentSeg.width) * 0.4;
        currentSeg.targetX = prevSeg.x - Math.cos(angle) * targetDistance;
        currentSeg.targetY = prevSeg.y - Math.sin(angle) * targetDistance;

        // Apply spring physics
        const fx =
          (currentSeg.targetX - currentSeg.x) * PHYSICS.SPRING_STIFFNESS;
        const fy =
          (currentSeg.targetY - currentSeg.y) * PHYSICS.SPRING_STIFFNESS;

        currentSeg.vx = currentSeg.vx * PHYSICS.FRICTION + fx;
        currentSeg.vy = currentSeg.vy * PHYSICS.FRICTION + fy;

        // Apply damping
        currentSeg.vx -= currentSeg.vx * PHYSICS.SPRING_DAMPING;
        currentSeg.vy -= currentSeg.vy * PHYSICS.SPRING_DAMPING;

        // Update position
        currentSeg.x += currentSeg.vx;
        currentSeg.y += currentSeg.vy;

        // Constrain to container
        const padding = 10;
        currentSeg.x = Math.max(
          padding,
          Math.min(
            containerSize.width - currentSeg.width - padding,
            currentSeg.x,
          ),
        );
        currentSeg.y = Math.max(
          padding,
          Math.min(
            containerSize.height - currentSeg.height - padding,
            currentSeg.y,
          ),
        );

        // Calculate rotation based on movement direction
        const segDx = currentSeg.x - currentSeg.lastX;
        const segDy = currentSeg.y - currentSeg.lastY;
        if (Math.abs(segDx) > 0.1 || Math.abs(segDy) > 0.1) {
          currentSeg.rotation = Math.atan2(segDy, segDx) * (180 / Math.PI);
        }

        // Store last position
        currentSeg.lastX = currentSeg.x;
        currentSeg.lastY = currentSeg.y;
      }

      return newSegments;
    });
  }, [segments, mousePos, containerSize]);

  // Start auto wobble effect
  const startAutoWobble = useCallback(() => {
    if (autoWobbleIntervalRef.current) {
      window.clearInterval(autoWobbleIntervalRef.current);
    }

    autoWobbleIntervalRef.current = window.setInterval(() => {
      setSegments((prevSegments) => {
        const newSegments = [...prevSegments];
        if (newSegments.length > 0) {
          newSegments[0] = {
            ...newSegments[0],
            vx: newSegments[0].vx + (Math.random() - 0.5) * 2,
            vy: newSegments[0].vy + (Math.random() - 0.5) * 2,
          };
        }
        return newSegments;
      });
    }, 2000);
  }, []);

  // Animation loop
  const animate = useCallback(() => {
    updatePhysics();
    animationFrameRef.current = requestAnimationFrame(animate);
  }, [updatePhysics]);

  // Initialize doge when container size is set
  useEffect(() => {
    if (containerSize.width > 0 && containerSize.height > 0) {
      initDoge();
    }
  }, [containerSize, initDoge]);

  // Start animation and auto wobble
  useEffect(() => {
    if (segments.length > 0) {
      startAutoWobble();
      animationFrameRef.current = requestAnimationFrame(animate);
    }

    return () => {
      if (autoWobbleIntervalRef.current) {
        window.clearInterval(autoWobbleIntervalRef.current);
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [segments.length, animate, startAutoWobble]);

  return {
    segments,
    handleMouseMove,
    triggerWobble,
    resetDoge,
  };
}
import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Physics constants for the doge wobble animation
export const PHYSICS = {
  SEGMENTS: 12, // Number of doge body segments
  SEGMENT_WIDTH: 60, // Width of each segment
  SEGMENT_HEIGHT: 40, // Height of each segment
  SPRING_STIFFNESS: 0.3, // Stiffness of the spring
  SPRING_DAMPING: 0.7, // Damping of the spring
  FRICTION: 0.95, // Friction applied to velocity
  MOUSE_INFLUENCE: 0.5, // How much mouse movement affects segments
};

// Colors for the doge
export const DOGE_COLORS = {
  primary: "#F2C94C", // Main body color
  secondary: "#F2994A", // Hover/active color
  dark: "#4F4F4F", // Eyes, nose, etc.
};
import * as React from "react";

import type { ToastActionElement, ToastProps } from "@/components/ui/toast";

const TOAST_LIMIT = 1;
const TOAST_REMOVE_DELAY = 1000000;

type ToasterToast = ToastProps & {
  id: string;
  title?: React.ReactNode;
  description?: React.ReactNode;
  action?: ToastActionElement;
};

const actionTypes = {
  ADD_TOAST: "ADD_TOAST",
  UPDATE_TOAST: "UPDATE_TOAST",
  DISMISS_TOAST: "DISMISS_TOAST",
  REMOVE_TOAST: "REMOVE_TOAST",
} as const;

let count = 0;

function genId() {
  count = (count + 1) % Number.MAX_SAFE_INTEGER;
  return count.toString();
}

type ActionType = typeof actionTypes;

type Action =
  | {
      type: ActionType["ADD_TOAST"];
      toast: ToasterToast;
    }
  | {
      type: ActionType["UPDATE_TOAST"];
      toast: Partial<ToasterToast>;
    }
  | {
      type: ActionType["DISMISS_TOAST"];
      toastId?: ToasterToast["id"];
    }
  | {
      type: ActionType["REMOVE_TOAST"];
      toastId?: ToasterToast["id"];
    };

interface State {
  toasts: ToasterToast[];
}

const toastTimeouts = new Map<string, ReturnType<typeof setTimeout>>();

const addToRemoveQueue = (toastId: string) => {
  if (toastTimeouts.has(toastId)) {
    return;
  }

  const timeout = setTimeout(() => {
    toastTimeouts.delete(toastId);
    dispatch({
      type: "REMOVE_TOAST",
      toastId: toastId,
    });
  }, TOAST_REMOVE_DELAY);

  toastTimeouts.set(toastId, timeout);
};

export const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case "ADD_TOAST":
      return {
        ...state,
        toasts: [action.toast, ...state.toasts].slice(0, TOAST_LIMIT),
      };

    case "UPDATE_TOAST":
      return {
        ...state,
        toasts: state.toasts.map((t) =>
          t.id === action.toast.id ? { ...t, ...action.toast } : t,
        ),
      };

    case "DISMISS_TOAST": {
      const { toastId } = action;

      // ! Side effects ! - This could be extracted into a dismissToast() action,
      // but I'll keep it here for simplicity
      if (toastId) {
        addToRemoveQueue(toastId);
      } else {
        state.toasts.forEach((toast) => {
          addToRemoveQueue(toast.id);
        });
      }

      return {
        ...state,
        toasts: state.toasts.map((t) =>
          t.id === toastId || toastId === undefined
            ? {
                ...t,
                open: false,
              }
            : t,
        ),
      };
    }
    case "REMOVE_TOAST":
      if (action.toastId === undefined) {
        return {
          ...state,
          toasts: [],
        };
      }
      return {
        ...state,
        toasts: state.toasts.filter((t) => t.id !== action.toastId),
      };
  }
};

const listeners: Array<(state: State) => void> = [];

let memoryState: State = { toasts: [] };

function dispatch(action: Action) {
  memoryState = reducer(memoryState, action);
  listeners.forEach((listener) => {
    listener(memoryState);
  });
}

type Toast = Omit<ToasterToast, "id">;

function toast({ ...props }: Toast) {
  const id = genId();

  const update = (props: ToasterToast) =>
    dispatch({
      type: "UPDATE_TOAST",
      toast: { ...props, id },
    });
  const dismiss = () => dispatch({ type: "DISMISS_TOAST", toastId: id });

  dispatch({
    type: "ADD_TOAST",
    toast: {
      ...props,
      id,
      open: true,
      onOpenChange: (open) => {
        if (!open) dismiss();
      },
    },
  });

  return {
    id: id,
    dismiss,
    update,
  };
}

function useToast() {
  const [state, setState] = React.useState<State>(memoryState);

  React.useEffect(() => {
    listeners.push(setState);
    return () => {
      const index = listeners.indexOf(setState);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    };
  }, [state]);

  return {
    ...state,
    toast,
    dismiss: (toastId?: string) => dispatch({ type: "DISMISS_TOAST", toastId }),
  };
}

export { useToast, toast };
import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
